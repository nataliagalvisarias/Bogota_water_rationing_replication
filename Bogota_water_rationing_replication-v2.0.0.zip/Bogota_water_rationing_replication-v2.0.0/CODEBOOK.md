# Codebook

The analytical data are aggregate rather than incident-level. The author confirms, on 27 October 2026, that the included daily outcome panels and monthly aggregates may be published; the underlying agreement has not been independently inspected. The native extract is not included. See `docs/DATA_ACCESS.md`. Dates use ISO `YYYY-MM-DD`; spatial measurements use metres in EPSG:3116 (MAGNA-SIRGAS / Colombia Bogotá zone). A positive treatment coefficient means that scheduled rationing increases reported domestic violence.

## Public inputs

### `data/public/hydraulic_polygons.gpkg`

Twelve municipal hydraulic service polygons used by EAAB. `polygon_id` is the stable polygon key. Geometry is stored in EPSG:3116.

### `data/public/rationing_calendar.csv`

One row per published schedule assignment, 306 rows from 11 April 2024 through the final shift beginning 11 April 2025. EAAB Resolución 182 de 2025 lifted the suspension at 08:00 on 12 April 2025; no later date is coded as rationed. `date` is the schedule date and `turno_group_id` is the rationing shift, numbered 1–9.

### `data/public/polygon_shift_crosswalk.csv`

Maps each `polygon_id` to its fixed `shift_id`.

## Derived inputs

### Repaired geography and spatial weights

`hydraulic_polygons_analysis.gpkg` is built from the retained public source by allocating overlap strips to the lowest polygon ID, independent of outcomes. The maximum removed area fraction is 0.0212%. `spatial_weights_binary.csv` and `spatial_weights_row_standardized.csv` have an explicit `polygon_id` row key and columns named by hydraulic polygon ID; `Turno` metadata is excluded. Binary weights are symmetric with zero diagonal. Row-standardized weights sum to one. `polygon_neighbors.csv` lists numeric neighbours: 6 → 11; 7 → 2, 8, 11.


### `data/derived/adjacency_pairs.csv`

Twenty cross-shift polygon pairs sharing a boundary of at least 100 metres. Fields are `boundary_id`, endpoint polygons `poly_a`/`poly_b`, `shared_length_m`, and endpoint shifts `shift_a`/`shift_b`.

### `data/derived/bandwidths_mserd.csv`

MSE-optimal bandwidths for fifteen boundaries, selected once and held fixed. `h_mserd` is the analysis bandwidth. Boundaries 1–8, 2–7, 6–11, 7–8 and 7–11 take the median of these fifteen values (480.86 m) because no bandwidth was selected for them; provenance is exported separately. The `rdrobust` columns are provenance fields only; active estimation is implemented directly in R.

### `data/derived/cell_exposure_area.csv`

1,598 fixed cells. Keys are `boundary_id`, `polygon_id`, and unsigned 50-metre-band midpoint `mag`. `lattice_pts` counts 50-metre lattice points and `area_m2` is their implied exposure area.

### `data/derived/monthly_maltrato_citywide.csv`

Twenty-eight citywide monthly counts from January 2023 through April 2025 for Figure 2. `maltrato_calls` counts all native-extract rows with `DESC_TIPO_INCIDENTE == "MALTRATO"`, without the `MALTRATO A MUJER` circumstance, geography, and deduplication restrictions used for estimation. The July 2023 dip is due to incomplete source records. The restricted rebuild recreates this file from the native extract; the public run reads the shipped counts.

### Fixed-geography and treatment-clock panels

- `panel_fixed_geography.csv.gz`: 477,802 rows, 1,598 cells × 299 usable calendar dates.
- `panel_operational_0800.csv.gz`: 485,792 rows, 1,598 cells × 304 usable operational water days.
- `panel_calendar_secondary.csv.gz`: 477,802 rows under the secondary 00:00–23:59 clock.

Shared variables:

| Variable | Definition |
|---|---|
| `boundary_id` | Polygon-pair boundary, lower polygon identifier first. |
| `side` | Endpoint side `a` or `b`; fixed over time. |
| `polygon_id` | Hydraulic service polygon. |
| `mag` | Unsigned distance-band midpoint: 25, 75, …, 1,975 metres. |
| `area_m2` | Cell exposure area. |
| `date` / `analysis_date` | Calendar or treatment-clock analysis date. |
| `shift` | Rationing shift scheduled that date. |
| `cycle_id` | Group of nine consecutive active rationing dates, one full pass through the shift sequence; calendar duration varies with policy frequency. |
| `rationed` | 1 when the cell’s polygon is assigned to the scheduled shift. |
| `active` | 1 when exactly one endpoint polygon is scheduled. |
| `n` | Count of qualifying reports; zero-filled. |
| `cell_id` | Fixed boundary × side × distance-band identifier. |
| `boundary_date_id` | Boundary × analysis-date fixed-effect identifier. |

### Along-boundary segment panels

- `panel_segments_500m.csv.gz`: 1,770,496 rows and 326 segments.
- `panel_segments_1000m.csv.gz`: 1,094,704 rows and 204 segments.

They add `segment_id` and `lattice_pts`. Their `cell_id` is boundary × segment × side × distance band; `boundary_date_id` is boundary × segment × date.

## Principal outputs

`polygon_estimation_coverage.csv` and `polygon_coverage_by_model.csv` check that all twelve polygons remain in the primary estimating sample and in every model sample after activity and bandwidth restrictions. `repaired_edge_estimates.csv` reports the four boundaries that involve polygons 6 and 7; `topology_*.csv` and `bandwidth_provenance.csv` document geometry and bandwidth decisions.


`primary_timing.csv` reports primary operational and secondary calendar ITTs, date- and cycle-clustered standard errors, the 63-date moving-block bootstrap interval, control mean, percentage scale, sample counts, and exposure-area aggregate.

`dynamic_event_time.csv`, `dynamic_cumulative.csv`, and `dynamic_tests.csv` report event times −2 through +2, the [−1,+1] window, and the joint lead test.

`common500_*.csv`, `along_boundary_segments.csv`, and `ppml.csv` report the common-bandwidth, segment, and count-functional-form checks. `placebo_*.csv` contains displaced-cutoff and shift-label placebo diagnostics. `manuscript_number_audit.csv` maps each audited CSV value to its literal display string in `manuscript/manuscript.tex`.

Figures 1, A1, A2 and C2 are manually composed QGIS maps supplied in `figures/`. Hydraulic polygon geography underlies these maps; Figure C2 also shows a background street layer whose exact source is not documented: Figure A1 shows the same twenty-edge adjacency used in estimation and Figure A2 uses the pinned boundary-specific bandwidths. No figure displays record-level domestic-violence locations.

## Additional-analysis outputs (`10_additional_analyses.R`)

- `ext_dynamic_event_time_pm3.csv`, `ext_dynamic_cumulative.csv`, `ext_dynamic_tests_pm3.csv`, `ext_dynamic_reference_share.csv`: event-time coefficients −3..+3, linear-combination sums (for example days 0 to +2) and pooled-window averages, joint lead and lag tests, and the share of polygon-dates outside each window.
- `ext_wild_cluster_bootstrap.csv`: wild cluster restricted bootstrap-t over 34 rotation cycles; `p_value_tau0` and test-inversion bounds (grid step 0.00005).
- `ext_block_length_sensitivity.csv`: moving-block standard errors and percentile intervals for blocks of 9 to 126 dates, same seed as the primary procedure.
- `ext_estimatorB_implied_weights.csv`: each boundary's share of the preferred estimator's identifying variation (`weight`), its within-boundary estimate, and its share of within-bandwidth cell-dates.
- `ext_estimatorB_windows.csv`, `ext_silent_days_excluded.csv`: preferred estimator under alternative windows and samples, with 63-date block intervals.
- `ext_heterogeneity.csv`: interaction estimates by date-level group; `pct_of_control` uses each group's comparison-side mean.
- `ext_placebo_displaced_operational.csv`, `ext_placebo_dense_operational.csv`, `ext_placebo_permutations_estimatorB.csv`, `ext_placebo_summary_operational.csv`: placebos on the primary operational specification.
- `ext_rotation_balance.csv`: day-of-week, phase and date composition of each side's scheduled dates.
- `ext_reconciliation.csv`: placement totals and usable dates by clock.
- `ext_active_boundary_counts.csv`: mean number of active boundaries per polygon-day when the polygon is rationed and when it is a comparison, and the correlation of that number with treatment (public inputs only).

## Optional restricted-path outputs

These files require the native extract (`00_master.R --full`) or external layers. They are not needed to reproduce any exhibit or number in the manuscript.

- `within_polygon_assignment_check.csv` and `exposure_balance_by_boundary.csv` (`03_build_fixed_geography.R`): by polygon, reports summed across active boundaries and per active boundary on rationed and comparison days; by boundary, exposure area on each side. Both are aggregates and are shipped.
- `restricted_*.csv` (`11_restricted_additional_analyses.R`): pre-programme placebo, other outcomes in the same extract, nearest-active-boundary assignment and its distance profile, and 1/k weighting. Aggregate estimates only.
- `ext_boundary_overlap.csv`, `ext_estrato_balance.csv`, `ext_estrato_heterogeneity.csv` and `data/derived/cell_estrato.csv` (`12_external_layers.R`): written only when administrative or stratification layers are supplied.

## Estimation conventions

- Counts are formed in half-open 50-metre distance bands; no cell spans the boundary.
- The primary clock assigns reports from 08:00 on date *t* through 07:59 on date *t+1* to the same suspension.
- Cell population is time invariant and absorbed by cell fixed effects; no population offset is used in the linear or PPML count models.
- The primary interval uses 1,000 moving-block draws with a block length of 63 analysis dates and seed 20240914.
- Shift-label permutations are placebo checks, not exact randomization inference.

## Disclosure and provenance qualification (27 October 2026)

Boundary, polygon, distance-band, date and segment keys encode indirect geography
and timing. Positive small counts remain; absence of direct incident identifiers
does not establish anonymity or a right to redistribute. Geometry-only exposure
areas and municipal geography require their own publisher attribution and terms.
The fine segment panels deserve particular review because their resolution is
finer along boundaries than the non-segment panels. Statistical outputs and
static exhibits should be included in the disclosure assessment.

The 15 pinned bandwidths can be used to reproduce the downstream analysis, but
the original bandwidth-selection computation is not included. `rdrobust`
provenance fields alone do not reproduce selection. Shipped monthly counts use
the broader MALTRATO classification and include source coverage problems; they
must not be interpreted as the female-circumstance estimation sample.

`cell_id` is an aggregate cell identifier, not an incident ID. "Incidents" or
`n_incidents` in boundary-panel outputs means report–boundary placements unless
explicitly stated otherwise; summing over boundaries can count a report more
than once. The 47-row manuscript audit checks string presence globally, not
contextual agreement of every reported result.
