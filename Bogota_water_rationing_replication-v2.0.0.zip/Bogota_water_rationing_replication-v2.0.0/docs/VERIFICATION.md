# Verification record

## Independent final audit: 27 October 2026

The existing package was preserved before edits. All **104** original manifest
entries matched their file sizes and MD5 hashes. The original package contained
106 files including the manifest and checksum files, totalling 36,652,327 bytes
(about 35.0 MiB). No zero-byte files, byte-identical duplicates or direct native
incident extracts were found. This establishes integrity of the supplied copy,
not data correctness or redistribution permission.

### Clean aggregate-input execution

A separate copy was made. Before running, the audit deleted **41** generated CSVs
from `output/`, all nine generated tables, Figures 2–7 and C1, the repaired
GeoPackage, adjacency, weight matrices and neighbour list. Two restricted-path
diagnostics were retained: `within_polygon_assignment_check.csv` and
`exposure_balance_by_boundary.csv`. Five shipped count panels, areas, monthly
counts and pinned bandwidths were retained as analytical inputs.

The unmodified analytical pipeline ran using:

```bash
Rscript --vanilla code/00_master.R
```

It exited successfully on macOS arm64, R 4.3.1, in approximately **331 seconds
(5.5 minutes)**, measured from run-log creation to its final write. CPU model and
peak RAM were not measured. Packages were `dplyr` 1.1.4, `readr` 2.1.5, `tidyr`
1.3.1, `sf` 1.0-20, `ggplot2` 3.5.1, `fixest` 0.12.1 and `tibble` 3.2.1. Native
libraries: GEOS 3.13.0, GDAL 3.8.5, PROJ 9.5.1. Warnings noted `sf` and `fixest`
were built under R 4.3.3; they did not prevent completion.

| Comparison | Independently observed result |
|---|---|
| Regenerated output CSVs | 41 of 41 recreated. 10 byte-identical; 31 differ in numerical serialisation. |
| Numerical/text comparison of all 43 output CSVs, including two retained diagnostics | Same row counts, columns and text; all numerical columns agree at `atol=1e-10`, `rtol=1e-8`, with corresponding missing values equal. Largest absolute numerical difference: approximately 1.012e-11. |
| Tables | 9 of 9 byte-identical. |
| Regenerated adjacency, weights and neighbour list | Byte-identical. |
| Repaired GeoPackage | File bytes differ; geometry WKB and non-geometry attributes are identical. |
| Figures 2–7 and C1 | All regenerated at the same page dimensions; **not pixel-identical** across these environments. Plotted source data agree numerically. Rendering differences remain; no pixel-identity claim is made. |
| Manuscript-number audit | 47 displayed strings found; independently checked against original CSV strings too. |

The shipped scientific data and statistical outputs were retained rather than
replaced by platform-specific serialisations. Subsequent candidate edits corrected
documentation, citation metadata, disclosure statements, a Figure C2 caption and
the manifest verifier. Analytical estimators, inputs and shipped results were not
changed.

### Independent data and estimation checks

All five compressed panels were fully read. Checks found no missing fields, no
duplicate cell-date keys, nonnegative integer counts, balanced cells over the
usable dates, all 20 boundaries, and zero discrepancies in treatment/activity
assignment, polygon-side mappings and available shift/cycle fields. Exposure
areas match the exposure input; fixed-geography counts match the secondary
calendar panel exactly. Both GeoPackages pass SQLite integrity checks and contain
12 polygon features in EPSG:3116.

| Panel | Rows | Cells | Usable dates | Report–boundary placements |
|---|---:|---:|---:|---:|
| Fixed geography | 477,802 | 1,598 | 299 | 111,890 |
| Secondary calendar | 477,802 | 1,598 | 299 | 111,890 |
| Primary operational | 485,792 | 1,598 | 304 | 111,427 |
| 500m segments | 1,770,496 | 5,824 | 304 | 27,446 |
| 1000m segments | 1,094,704 | 3,601 | 304 | 27,453 |

Independent Python/numpy two-way fixed-effects calculations reproduced primary,
secondary and both segment point estimates within 6.5e-17 of their shipped
values, and reproduced corresponding clustered standard errors. The primary
identifying sample has 27,470 cell-days and 6,106 placements; its coefficient is
approximately 0.0003836223. This independently verifies downstream arithmetic,
not the truth/completeness of the restricted records or the identification design.

### Portability fix and final-source checks

The original R manifest verifier failed on macOS despite correct hashes because
its `sort()` used platform locale collation. It now uses radix ordering and
inventories all files except Git internals and the two self-referential inventory
files. Disclosure labels record aggregate publication as author-confirmed, following
the author’s clarification; the agreement itself was not independently inspected. The release maintainer must refresh only after reviewing
intentional changes, then check the exact candidate and downloaded archive.

All 14 R scripts parse. The revised packaged manuscript compiled successfully
with the desktop editor’s built-in compiler after the documentation/caption
edits. This confirms successful source compilation; the previous submission PDF
has not been replaced, and a newly exported compiled PDF still needs final visual
review and synchronisation with the journal upload set. The compiler result did
not provide a page count or an exported PDF. No new claim of a 56-page output is
made.

### Limitations and publication blockers

- The author confirms the included aggregates may be published. The underlying
  agreement was not independently inspected. Counts of one remain (57,467 rows
  in the operational panel); individual records and incident coordinates remain
  excluded. No aggregate-permission blocker remains in this audit.
- Raw-to-aggregate reconstruction (`--full`) and optional layers were not run;
  their inputs were unavailable. The default pipeline depends upstream on the
  restricted records, despite not requiring them at run time.
- Original bandwidth selection is not reproduced; 15 pinned values and five
  median fallbacks are used.
- Four manual maps lack QGIS projects/export recipes. Figure C2 has a background
  street layer whose exact source is not documented. Its original caption
  incorrectly described distinct colours for all shifts and polygon-ID labels;
  the packaged source now describes the actual highlighted shifts and labels.
  Figure A1’s legend omits the one-neighbour class and needs QGIS correction.
- The 47-string audit searches globally; it does not verify contextual mapping or
  every manuscript number. It does not include a complete map/caption audit.
- No exact dependency lock/container, independent Windows execution or complete
  public-source provenance/licence register is supplied.
- Existing Zenodo v1 is a different archive. The author subsequently supplied version DOI `10.5281/zenodo.23700240`; its public resolution must be checked after publication.

## Supplied historical Linux verification claim

The original `VERIFICATION.md` reported R 4.3.3 on Linux, approximately eight
minutes, 43/43 identical CSVs, nine identical tables, pixel-identical statistical
figures and a 56-page manuscript build. No original full console log was included
in this package. That historical claim is distinguished from the new independent
Mac results above. In particular, only 41 of the 43 CSVs are regenerated by the
default pipeline. `session_info.txt` is retained unchanged as the supplied Linux
environment record; `audit_session_info_macos.txt` records the current dependency
session separately.

Detailed evidence and logs for this review are kept in the adjacent internal
`04_Audit_Report/2026-10-27_QC/` folder, outside the replication package. That
folder is not intended for public archival upload.
