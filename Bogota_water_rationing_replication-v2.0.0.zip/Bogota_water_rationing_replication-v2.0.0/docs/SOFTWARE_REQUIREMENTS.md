# Software requirements and environment evidence

## R dependencies

| Package | Supplied historical Linux record | Mac audit installation, 27 October 2026 | Use |
|---|---|---|---|
| R | 4.3.3 | 4.3.1 | R >=4.1 syntax required. |
| dplyr | 1.1.4 | 1.1.4 | Data preparation and joins. |
| readr | 2.1.5 | 2.1.5 | CSV/gzip input and output. |
| tidyr | 1.3.1 | 1.3.1 | Panel expansion and reshaping. |
| sf | 1.0-15 | 1.0-20 | Geometry and CRS handling. |
| ggplot2 | 3.4.4 | 3.5.1 | Statistical figures. |
| fixest | 0.12.1 | 0.12.1 | PPML and fixed-effects estimation. |
| tibble | 3.2.1 | 3.2.1 | Tabular objects. |
| lwgeom | Not recorded | 0.2-14 | Restricted segment rebuild only. |

The master checks package availability before the analytical run. Rscript should
be on PATH. A plain session profile can change options, locale or environment;
use `Rscript --vanilla` and a fresh process for replication.

The supplied `session_info.txt` is a historical record that reports Linux, R
4.3.3, GDAL 3.8.4, GEOS 3.12.1 and PROJ 9.4.0. It is preserved as supplied,
not certified as a newly reproduced session. There is no machine-restorable
lockfile or container. Installing current CRAN packages will not necessarily
restore the historical environment. If creating `renv.lock`, generate it from a
verified complete environment and test `renv::restore()` in a fresh library;
do not manufacture a lockfile from a partial package list.

Capture an actual session after the master runs, for example in R:

```r
sessionInfo()
sf::sf_extSoftVersion()
Sys.getlocale()
Sys.timezone()
```

## Randomness and numerical behaviour

Script 05 sets seed 20240914, uses 1,000 moving-block draws and a 63-active-date
block. Script 10 resets seeds for comparisons, uses 9,999 wild-bootstrap draws
per weight family and 999 primary-specification permutations (seed 20240411).
Script 04 has its own seeded placebo simulation. Do not lower draw counts for a
release verification. `fixest` uses one thread in the robustness/additional
scripts. BLAS, geometry libraries, R random-number algorithms and fonts can
still affect cross-platform results. Numerical and rendering comparisons should
be recorded separately from exact hashes.

## System dependencies and optional software

`sf` needs GDAL, GEOS, PROJ and units support. Install compatible CRAN binaries
where available, or follow the official sf installation instructions for the
operating system. Installation can need internet access; the default data and
analysis run needs no remote downloads.

Manuscript compilation uses `pdflatex`, BibTeX, `plainnat`, and packages:
`inputenc`, `fontenc`, `amsmath`, `amssymb`, `amsfonts`, `graphicx`, `booktabs`,
`threeparttable`, `float`, `array`, `multirow`, `geometry`, `setspace`, `natbib`,
`hyperref`, `footmisc`. TeX Live or an equivalent installation is sufficient
when these packages and fonts are available. The final Mac audit did not find
`pdflatex` on PATH. The revised manuscript nevertheless compiled successfully
using the desktop editor’s built-in compiler; no new submission PDF was exported
or visually certified.

QGIS is needed to edit the four supplied manual maps, but an exact project and
export workflow are not included. QGIS is not called by the default R pipeline.
No Python package is needed to execute the replication package; Python used for
independent audit checks is kept outside the package.

## Resource and portability limits

The supplied historical runtime is about eight minutes on one core. CPU model,
peak RAM and full restricted-path runtime were not documented. The audit report
records the new Mac verification outcome. Windows was not independently tested.
Run from the package root, preserve filename case, use quoted paths with spaces,
and keep raw inputs external. `%b` month parsing in restricted inputs depends on
`LC_TIME`; inspect failures rather than silently dropping them. Optional
`ADMIN_LAYERS` parsing uses semicolon-separated `label=path` pairs; paths with
those delimiters are unsupported.

The current native-library capture is GEOS 3.13.0, GDAL 3.8.5 and PROJ 9.5.1; see `audit_session_info_macos.txt`.
