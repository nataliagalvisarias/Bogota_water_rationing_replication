# Data access, redistribution and disclosure

## Current permission statement

**27 October 2026: the author confirms that the included aggregate data may be published.** Individual emergency-call records and their x/y coordinates may not be redistributed and are not included.

This statement records the author’s confirmation, rather than independent inspection of a data-use agreement. Recording a relevant terms/reference note would strengthen the archival provenance, but this review does not require publication of a signed agreement.

The research extract is held by Bogotá’s *Secretaría Distrital de Seguridad, Convivencia y Justicia* and originates from the C4/Línea 123 Emergency Response Center. Incident-level records are not included. The package contains daily count panels and a monthly citywide series derived from those records. The author confirms publication is allowed for these aggregates; the restriction on individual records remains in effect.

## How another researcher can request access

Request an equivalent research extract from the Secretariat through [Bogotá te escucha](https://bogota.gov.co/yo-participo). Identify the research purpose, required period, intended derived outputs, institutional affiliation, secure storage and intended publication. The existing package does not include the original request ID, signed agreement, delivery version, access cost, expected waiting time, or eligibility criteria. Record these if available; do not imply that access is automatic or that contacting the author guarantees access.

Ask for all Línea 123 reports in broad `MALTRATO` from January 2023 through at least April 2025 (the original documentation requested through May 2025), including `MALTRATO A MUJER` and all circumstances needed for the broader citywide descriptive series. The extraction must include 00:00–07:59 on 12 April 2025 to finish the last operational water day.

The Secretariat’s [C4/NUSE open-data series](https://www.scj.gov.co/transparencia/datos-abiertos/incidentes-tramitados-en-el-c4-numero-unico-de-seguridad-y-emergencias) is a discovery route, **not a verified substitute**. Compare coverage, definitions, fields, revision history and geocoding with the research extract before use. The links are supplied access routes; successful delivery and extract equivalence were not verified in this audit.

## Exact native input contract

The `.dsv` adapter in script 02 reads a semicolon-delimited file with the following exact, case-sensitive fields:

| Field | Expected content |
|---|---|
| `ID_INCIDENTE` | Incident identifier; converted to character; one retained row per ID. |
| `FECHA` | Date parsed with `%d-%b-%y`; month abbreviations depend on the R `LC_TIME` locale. |
| `HORA` | Integer hour, 0–23; strings such as `08:30` are not supported by the adapter. |
| `DESC_TIPO_INCIDENTE` | Exact `MALTRATO` for the descriptive/estimation filters. |
| `CIRCUNSTANCIA_INCIDENTE` | Exact `MALTRATO A MUJER` for the estimation outcome. |
| `LATITUD`, `LONGITUD` | Numeric WGS84 coordinates (EPSG:4326); zero/non-finite coordinates are filtered. |

For a GeoPackage, the adapter expects `id_inciden`, `fecha`, `hora`, `desc_tipo_`, `circunstan` and valid spatial geometry with an identified CRS. Script 02 transforms coordinates to EPSG:3116. This is not a generic schema importer. Verify that code labels and formats match the delivered version.

Deduplication uses `distinct(crime_id, .keep_all = TRUE)`: it retains the first record per ID. This differs from removing only identical duplicate rows. Document the source ordering and how updates/duplicate IDs are handled. Verify missing IDs, date parsing failures, coordinate plausibility and source record coverage before rebuilding. The current code infers usable dates from observed qualifying reports: no-report dates may reflect missing data or true zeros, so a custodian coverage ledger is needed to distinguish them.

## Restricted rebuild

Keep raw files outside the replication package. From its root in a macOS/Linux shell:

```bash
INPUT_ROOT="/absolute/path/to/authorised/data" \
INCIDENTS_ALL="/absolute/path/to/authorised/data/raw/NUSE_NGA.dsv" \
Rscript --vanilla code/00_master.R --full
```

The Windows PowerShell equivalent is in the README. `INPUT_ROOT` is validated as a directory; `INCIDENTS_ALL` identifies the actual file. `--full` stops without valid paths. Use a fresh R process and the documented `lwgeom` dependency. The restricted and optional external-layer paths were not executed in the final audit.

Script 02 retains incidents in memory and exports the monthly aggregate series. Script 03 writes fixed-geography counts, exposure areas and diagnostics. Scripts 05/06 rebuild clock and segment panels; script 11 adds restricted aggregate diagnostics. The intended outputs exclude incident coordinates and case IDs. That intended behaviour is not a substitute for inspection of an actual restricted rebuild and its outputs before release.

## Disclosure review and evidence required

The daily panels contain boundary, side, distance, polygon, date and segment identifiers, with unsuppressed small counts. Public boundary geometry can help interpret those locations. Removing direct names/coordinates is insufficient to establish that the panels are non-identifying.

The author’s confirmation covers publication of the included aggregate data. Keep the individual incident extract external, retain only the intended aggregate outputs, and record the applicable source terms if a reference is available. A confidential agreement need not be published. Small counts are a documented property of these aggregate files, not evidence by themselves that publication is prohibited.

The previous `v1` archive does not identify this revised package. Use a new version for the final files and accurate metadata, independently of the permission clarification.

## Rights by material

- Author-owned code: MIT.
- Author-created outcome aggregates: publication permitted according to the author; designated CC BY 4.0 in `LICENSE`. Underlying agreement not independently inspected.
- EAAB/Bogotá public inputs and derived geography: original publisher terms and attribution; exact terms/version references need recording.
- Restricted incidents: not included or offered for redistribution.

Data and code access questions: [Natalia Galvis Arias](mailto:natalia.galvisarias@postgrad.manchester.ac.uk). Do not include incident information in public issue reports.
