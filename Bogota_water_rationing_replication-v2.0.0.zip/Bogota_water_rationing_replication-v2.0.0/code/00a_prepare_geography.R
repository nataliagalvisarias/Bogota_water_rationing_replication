#!/usr/bin/env Rscript
## Resolve narrow digitising overlaps before defining shared-edge adjacency.
## The source GeoPackage is retained unchanged. Ascending polygon_id has priority
## in overlap strips; this rule uses neither incidents nor treatment dates.
suppressPackageStartupMessages({library(sf);library(dplyr);library(readr)})
ROOT <- Sys.getenv("ROOT", ".")
DER <- file.path(ROOT,"data","derived"); OUT <- file.path(ROOT,"output")
dir.create(DER,recursive=TRUE,showWarnings=FALSE)
dir.create(OUT,recursive=TRUE,showWarnings=FALSE)
p <- st_read(file.path(ROOT,"data","public","hydraulic_polygons.gpkg"),quiet=TRUE) |>
  st_zm(drop=TRUE) |> st_make_valid() |> arrange(polygon_id)
stopifnot(st_crs(p)$epsg==3116L,!anyDuplicated(p$polygon_id),nrow(p)==12L)
before <- as.numeric(st_area(p))
source_poly <- p
source_pairs <- bind_rows(lapply(seq_len(nrow(p)-1L),function(i)
  bind_rows(lapply((i+1L):nrow(p),function(j) {
    a <- st_geometry(p[i,]);b <- st_geometry(p[j,])
    tibble(poly_a=p$polygon_id[i],poly_b=p$polygon_id[j],
           shared_length_raw_m=sum(as.numeric(st_length(st_intersection(st_boundary(a),st_boundary(b))))),
           overlap_raw_m2=sum(as.numeric(st_area(st_intersection(a,b)))))
  }))))
write_csv(source_pairs,file.path(OUT,"topology_source_pairs.csv"))
g <- st_difference(st_geometry(p))
stopifnot(identical(as.integer(attr(g,"idx")),seq_len(nrow(p))))
st_geometry(p) <- g
after <- as.numeric(st_area(p))
audit <- tibble(polygon_id=p$polygon_id,source_area_m2=before,
               analysis_area_m2=after,removed_overlap_m2=before-after,
               removed_fraction=(before-after)/before,
               rule="ascending polygon_id overlap priority")
## Stop rather than silently repair a substantive geographical disagreement.
stopifnot(all(st_is_valid(p)),!any(st_is_empty(p)),
          all(audit$removed_fraction>=-1e-10),all(audit$removed_fraction<0.001))
edge_keys <- function(z) {
  keys <- character()
  for(i in seq_len(nrow(z)-1L)) for(j in (i+1L):nrow(z)) {
    shared <- sum(as.numeric(st_length(st_intersection(
      st_boundary(st_geometry(z[i,])),st_boundary(st_geometry(z[j,]))))))
    if(shared>=100) keys <- c(keys,paste(sort(c(z$polygon_id[i],z$polygon_id[j])),collapse="_"))
  }
  sort(keys)
}
alternate <- source_poly[rev(seq_len(nrow(source_poly))),]
alt_geom <- st_difference(st_geometry(alternate))
alternate <- alternate[attr(alt_geom,"idx"),];st_geometry(alternate) <- alt_geom
primary_edges <- edge_keys(p);alternate_edges <- edge_keys(alternate)
stopifnot(length(primary_edges)==20L,identical(primary_edges,alternate_edges))
write_csv(tibble(priority=c("ascending polygon_id (primary)","descending polygon_id (membership check)"),
                 n_edges=c(length(primary_edges),length(alternate_edges)),
                 same_edge_set=TRUE),file.path(OUT,"topology_priority_sensitivity.csv"))
analysis_path <- file.path(DER,"hydraulic_polygons_analysis.gpkg")
same_geometry <- FALSE
if (file.exists(analysis_path)) {
  prior <- st_read(analysis_path,quiet=TRUE)
  same_geometry <- identical(prior$polygon_id,p$polygon_id) &&
    identical(st_as_binary(st_geometry(prior)),st_as_binary(st_geometry(p)))
}
if (!same_geometry) st_write(p,analysis_path,
  layer="hydraulic_polygons_analysis",delete_layer=TRUE,quiet=TRUE)
write_csv(audit,file.path(OUT,"topology_area_audit.csv"))
message("[00a] topology repaired; largest removed area fraction: ",
        signif(max(audit$removed_fraction),5))
