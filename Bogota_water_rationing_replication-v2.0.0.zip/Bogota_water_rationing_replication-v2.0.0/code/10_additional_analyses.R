#!/usr/bin/env Rscript
## =============================================================================
## 10_additional_analyses.R -- additional analyses that can be computed from the
## released aggregate panels (public path).
##
##  E1  Dynamics, event time -3..+3; cumulative [0,+2] and [-1,+1] sums and
##      pooled-window averages.
##  E2  Inference: wild cluster restricted (WCR) bootstrap-t on the 34
##      nine-assignment rotation cycles (Rademacher and Webb weights), with a
##      test-inversion interval; moving-block length sensitivity.
##  E3  Estimator B: implied boundary weights; common 500 m and full 2,000 m
##      windows.
##  E4  Heterogeneity: daily vs alternate-day phase, first vs second half of the
##      programme, weekend vs weekday water days.
##  E5  Placebos on the primary specification: displaced cutoffs on the
##      operational panel, and shift-label permutations of Estimator B itself.
##  E6  Rotation balance: calendar composition of each side's scheduled dates.
##  E7  Water days touching citywide-silent calendar dates removed.
##  E8  Reconciliation of clock-specific totals and usable dates.
##  E9  Number of active boundaries per polygon-day by treatment status.
##
## Every estimator below is the one used in 05/06 (same demeaning, same
## small-sample-corrected cluster formula, same seed), so results are directly
## comparable with Table 1.
## =============================================================================
suppressPackageStartupMessages({library(dplyr); library(readr); library(tidyr); library(fixest)})
fixest::setFixest_nthreads(1L)
ROOT <- Sys.getenv("ROOT", "."); DER <- file.path(ROOT, "data", "derived")
PUB <- file.path(ROOT, "data", "public"); OUT <- file.path(ROOT, "output")
SEED <- 20240914L; BLOCK_L <- 63L; N_BOOT <- 1000L; N_WILD <- 9999L; N_PERM <- 999L
ALT_START <- as.Date("2024-07-01"); ALT_END <- as.Date("2024-09-28")

pan <- read_csv(file.path(DER, "panel_operational_0800.csv.gz"), show_col_types = FALSE) |>
  mutate(analysis_date = as.Date(analysis_date))
pcal <- read_csv(file.path(DER, "panel_calendar_secondary.csv.gz"), show_col_types = FALSE) |>
  mutate(analysis_date = as.Date(analysis_date))
adj <- read_csv(file.path(DER, "adjacency_pairs.csv"), show_col_types = FALSE)
bws <- read_csv(file.path(DER, "bandwidths_mserd.csv"), show_col_types = FALSE)
cal <- read_csv(file.path(PUB, "rationing_calendar.csv"), show_col_types = FALSE) |>
  transmute(date = as.Date(date), shift = as.integer(turno_group_id)) |>
  arrange(date) |> mutate(cycle_id = (row_number() - 1L) %/% 9L + 1L)
xw <- read_csv(file.path(PUB, "polygon_shift_crosswalk.csv"), show_col_types = FALSE)
p2s <- setNames(xw$shift_id, as.character(xw$polygon_id))
bnds <- sort(unique(adj$boundary_id))
Hb <- setNames(bws$h_mserd[match(bnds, bws$boundary_id)], bnds); Hb[is.na(Hb)] <- median(bws$h_mserd)

## ---- estimators copied verbatim from 05/06 ----------------------------------
demeanK <- function(v, idx, nlev, tol = 1e-10, maxit = 1000L) {
  v <- as.numeric(v)
  for (iter in seq_len(maxit)) {
    old <- v
    for (j in seq_along(idx)) v <- v - (rowsum(v, idx[[j]]) / tabulate(idx[[j]], nlev[j]))[idx[[j]]]
    if (max(abs(v - old)) < tol) break
  }
  v
}
fe_fit <- function(d, y = d$n, x = d$rationed) {
  fs <- list(factor(d$cell_id), factor(d$boundary_date_id)); idx <- lapply(fs, as.integer)
  nl <- vapply(fs, nlevels, integer(1)); yy <- demeanK(y, idx, nl); xx <- demeanK(x, idx, nl)
  den <- sum(xx * xx); if (!is.finite(den) || den <= 0) return(NULL)
  tau <- sum(xx * yy) / den
  list(tau = tau, x = xx, y = yy, residual = yy - tau * xx, den = den, K = sum(nl) + 1L, n = nrow(d))
}
cluster_se <- function(fit, cl) {
  score <- vapply(split(seq_along(cl), cl), function(ii) sum(fit$x[ii] * fit$residual[ii]), numeric(1))
  G <- length(score)
  sqrt(sum(score^2) / fit$den^2 * (G / (G - 1)) * ((fit$n - 1) / (fit$n - fit$K)))
}
moving_block_draws <- function(d, L = BLOCK_L, B = N_BOOT) {
  dates <- sort(unique(d$analysis_date)); nd <- length(dates); by_date <- split(seq_len(nrow(d)), d$analysis_date)
  vapply(seq_len(B), function(rep) {
    starts <- sample.int(nd - L + 1L, ceiling(nd / L), replace = TRUE)
    chosen <- dates[unlist(lapply(starts, function(s) s:(s + L - 1L)))][seq_len(nd)]
    lens <- lengths(by_date[as.character(chosen)])
    s <- d[unlist(by_date[as.character(chosen)], use.names = FALSE), ]
    s$boundary_date_id <- paste(s$boundary_id, rep(seq_along(chosen), lens), sep = "|")
    z <- fe_fit(s); if (is.null(z)) NA_real_ else z$tau
  }, numeric(1))
}
fe_multi <- function(d, X) {
  fs <- list(factor(d$cell_id), factor(d$boundary_date_id)); idx <- lapply(fs, as.integer)
  nl <- vapply(fs, nlevels, integer(1)); yd <- demeanK(d$n, idx, nl)
  Xd <- apply(as.matrix(X), 2, demeanK, idx = idx, nlev = nl)
  if (is.null(dim(Xd))) Xd <- matrix(Xd, ncol = 1)
  keep <- apply(Xd, 2, function(z) sum(z^2) > 1e-12); Xd <- Xd[, keep, drop = FALSE]
  bread <- solve(crossprod(Xd)); beta <- as.numeric(bread %*% crossprod(Xd, yd))
  u <- as.numeric(yd - Xd %*% beta)
  list(beta = beta, X = Xd, u = u, bread = bread, K = sum(nl) + ncol(Xd), n = nrow(d), keep = keep)
}
cluster_vcov_multi <- function(fit, cl) {
  meat <- matrix(0, ncol(fit$X), ncol(fit$X))
  for (ii in split(seq_along(cl), cl)) {sc <- crossprod(fit$X[ii, , drop = FALSE], fit$u[ii]); meat <- meat + tcrossprod(sc)}
  G <- n_distinct(cl)
  fit$bread %*% meat %*% fit$bread * (G / (G - 1)) * ((fit$n - 1) / (fit$n - fit$K))
}
in_bandwidth <- function(p, h = Hb) p |> filter(active == 1L, mag < as.numeric(h[boundary_id]))
base_mean <- function(d) mean(d$n[d$rationed == 0L])

## Headline summary with the same moving-block procedure and seed as 05.
headline <- function(d, label, seed = SEED, L = BLOCK_L) {
  fit <- fe_fit(d); set.seed(seed); bt <- moving_block_draws(d, L = L); bt <- bt[is.finite(bt)]
  b <- base_mean(d)
  tibble(specification = label, tau = fit$tau, se_date = cluster_se(fit, d$analysis_date),
         se_cycle9 = cluster_se(fit, d$cycle_id), boot_se = sd(bt),
         ci_lo = unname(quantile(bt, .025)), ci_hi = unname(quantile(bt, .975)),
         control_mean = b, pct = 100 * fit$tau / b,
         ci_pct_lo = 100 * unname(quantile(bt, .025)) / b, ci_pct_hi = 100 * unname(quantile(bt, .975)) / b,
         n_rows = nrow(d), n_dates = n_distinct(d$analysis_date), n_placements = sum(d$n),
         n_boundaries = n_distinct(d$boundary_id))
}

d0 <- in_bandwidth(pan)
H0 <- headline(d0, "Primary (boundary-specific bandwidths)")
ref <- read_csv(file.path(OUT, "primary_timing.csv"), show_col_types = FALSE)[1, ]
stopifnot(abs(H0$tau - ref$tau) < 1e-12, abs(H0$ci_lo - ref$ci_lo_63) < 1e-12,
          abs(H0$ci_hi - ref$ci_hi_63) < 1e-12)
message("[10] headline reproduced exactly: tau ", signif(H0$tau, 6))

## =============================================================================
## E1 dynamics
## =============================================================================
nearest_event <- function(day, shift) {ev <- cal$date[cal$shift == shift]; delta <- as.integer(day - ev); delta[which.min(abs(delta))]}
pd <- pan |> distinct(polygon_id, analysis_date) |>
  mutate(own_shift = as.integer(p2s[as.character(polygon_id)]),
         event_time = mapply(nearest_event, analysis_date, own_shift))
dyn <- pan |> left_join(pd |> select(polygon_id, analysis_date, event_time), by = c("polygon_id", "analysis_date")) |>
  filter(mag < as.numeric(Hb[boundary_id]))
dyn_model <- function(ks) {
  X <- sapply(ks, function(k) as.integer(dyn$event_time == k)); colnames(X) <- paste0("k", ks)
  f <- fe_multi(dyn, X); V <- cluster_vcov_multi(f, dyn$cycle_id)
  list(ks = ks[f$keep], beta = f$beta, V = V)
}
lincomb <- function(m, set, label, window) {
  w <- as.numeric(m$ks %in% set); est <- sum(w * m$beta); se <- sqrt(as.numeric(t(w) %*% m$V %*% w))
  tibble(window_model = window, combination = label, estimate = est, se_cycle9 = se,
         ci_lo = est - 1.96 * se, ci_hi = est + 1.96 * se)
}
pooled_window <- function(lo, hi, label) {
  X <- matrix(as.integer(dyn$event_time >= lo & dyn$event_time <= hi), ncol = 1)
  f <- fe_multi(dyn, X); V <- cluster_vcov_multi(f, dyn$cycle_id); se <- sqrt(V[1, 1])
  tibble(window_model = "pooled indicator", combination = label, estimate = f$beta[1], se_cycle9 = se,
         ci_lo = f$beta[1] - 1.96 * se, ci_hi = f$beta[1] + 1.96 * se)
}
m2 <- dyn_model(-2:2); m3 <- dyn_model(-3:3)
ev3 <- tibble(event_time = m3$ks, estimate = m3$beta, se_cycle9 = sqrt(diag(m3$V))) |>
  mutate(ci_lo = estimate - 1.96 * se_cycle9, ci_hi = estimate + 1.96 * se_cycle9)
lead3 <- which(m3$ks < 0); W3 <- as.numeric(t(m3$beta[lead3]) %*% solve(m3$V[lead3, lead3]) %*% m3$beta[lead3])
lag3 <- which(m3$ks > 0); WL3 <- as.numeric(t(m3$beta[lag3]) %*% solve(m3$V[lag3, lag3]) %*% m3$beta[lag3])
dyn_tests <- tibble(model = "event time -3..+3",
                    test = c("Joint leads k=-3,-2,-1", "Joint lags k=+1,+2,+3"),
                    statistic = c(W3, WL3), df = c(length(lead3), length(lag3)),
                    p_value = pchisq(c(W3, WL3), c(length(lead3), length(lag3)), lower.tail = FALSE))
cums <- bind_rows(
  lincomb(m2, 0:2, "sum k=0..2", "event time -2..+2"),
  lincomb(m2, -1:1, "sum k=-1..+1", "event time -2..+2"),
  lincomb(m3, 0:2, "sum k=0..2", "event time -3..+3"),
  lincomb(m3, 0:3, "sum k=0..3", "event time -3..+3"),
  lincomb(m3, -1:1, "sum k=-1..+1", "event time -3..+3"),
  pooled_window(0, 2, "average day in [0,+2]"),
  pooled_window(-1, 1, "average day in [-1,+1]"))
ref_days <- dyn |> distinct(polygon_id, analysis_date, event_time) |>
  summarise(share_outside_pm2 = mean(abs(event_time) > 2), share_outside_pm3 = mean(abs(event_time) > 3))
cums <- cums |> mutate(control_mean = base_mean(d0), pct_of_control = 100 * estimate / control_mean)
write_csv(ev3, file.path(OUT, "ext_dynamic_event_time_pm3.csv"))
write_csv(cums, file.path(OUT, "ext_dynamic_cumulative.csv"))
write_csv(dyn_tests, file.path(OUT, "ext_dynamic_tests_pm3.csv"))
write_csv(ref_days, file.path(OUT, "ext_dynamic_reference_share.csv"))
message("[10] E1 dynamics done")

## =============================================================================
## E2 inference
## =============================================================================
fit0 <- fe_fit(d0); G_id <- as.integer(factor(d0$cycle_id)); G <- max(G_id)
fs <- list(factor(d0$cell_id), factor(d0$boundary_date_id)); idx <- lapply(fs, as.integer); nl <- vapply(fs, nlevels, integer(1))
xt <- fit0$x; yt <- fit0$y; D <- fit0$den
cfac <- (G / (G - 1)) * ((fit0$n - 1) / (fit0$n - fit0$K))
se_hat <- cluster_se(fit0, d0$cycle_id)
wild <- function(type, B = N_WILD, seed = SEED) {
  set.seed(seed)
  V <- switch(type,
    rademacher = matrix(sample(c(-1, 1), B * G, replace = TRUE), B, G),
    webb = matrix(sample(c(-sqrt(1.5), -1, -sqrt(.5), sqrt(.5), 1, sqrt(1.5)), B * G, replace = TRUE), B, G))
  Q <- as.numeric(rowsum(xt * xt, G_id))
  SA <- matrix(0, B, G); SC <- matrix(0, B, G)
  for (b in seq_len(B)) {   # M(y v) and M(x v) re-absorb the fixed effects in each draw
    vb <- V[b, G_id]
    A <- demeanK(yt * vb, idx, nl, tol = 1e-12); C <- demeanK(xt * vb, idx, nl, tol = 1e-12)
    SA[b, ] <- rowsum(xt * A, G_id)[, 1]; SC[b, ] <- rowsum(xt * C, G_id)[, 1]
  }
  pval <- function(t0) {
    dlt <- (rowSums(SA) - t0 * rowSums(SC)) / D
    S <- SA - t0 * SC - outer(dlt, Q)
    tstar <- dlt / (sqrt(cfac * rowSums(S^2)) / D)
    mean(abs(tstar) >= abs((fit0$tau - t0) / se_hat))
  }
  grid <- seq(-0.04, 0.04, by = 0.00005); pv <- vapply(grid, pval, numeric(1)); acc <- grid[pv > 0.05]
  tibble(weights = type, clusters = G, draws = B, tau = fit0$tau, se_cycle9 = se_hat,
         p_value_tau0 = pval(0), ci_lo = min(acc), ci_hi = max(acc),
         ci_pct_lo = 100 * min(acc) / base_mean(d0), ci_pct_hi = 100 * max(acc) / base_mean(d0),
         grid_step = 0.00005)
}
wcr <- bind_rows(wild("rademacher"), wild("webb"))
write_csv(wcr, file.path(OUT, "ext_wild_cluster_bootstrap.csv"))
message("[10] E2 wild bootstrap done")

blocks <- bind_rows(lapply(c(9L, 18L, 27L, 36L, 45L, 63L, 90L, 126L), function(L) {
  set.seed(SEED); bt <- moving_block_draws(d0, L = L); bt <- bt[is.finite(bt)]
  tibble(block_length = L, boot_se = sd(bt), ci_lo = unname(quantile(bt, .025)),
         ci_hi = unname(quantile(bt, .975)), n_boot = length(bt))
})) |> mutate(ci_pct_lo = 100 * ci_lo / base_mean(d0), ci_pct_hi = 100 * ci_hi / base_mean(d0))
stopifnot(abs(blocks$ci_lo[blocks$block_length == 63L] - ref$ci_lo_63) < 1e-12)
write_csv(blocks, file.path(OUT, "ext_block_length_sensitivity.csv"))
message("[10] E2 block-length sensitivity done")

## =============================================================================
## E3 implied weights and alternative windows for Estimator B
## =============================================================================
wt <- tibble(boundary_id = d0$boundary_id, xx = xt^2, xy = xt * yt) |>
  group_by(boundary_id) |> summarise(sxx = sum(xx), sxy = sum(xy), .groups = "drop") |>
  mutate(weight = sxx / sum(sxx), tau_within = sxy / sxx)
cells_bw <- d0 |> group_by(boundary_id) |>
  summarise(cells_in_bw = n_distinct(cell_id), active_dates = n_distinct(analysis_date), .groups = "drop")
wt <- wt |> left_join(cells_bw, by = "boundary_id") |>
  mutate(bandwidth = as.numeric(Hb[boundary_id]),
         cell_date_share = cells_in_bw * active_dates / sum(cells_in_bw * active_dates))
stopifnot(abs(sum(wt$weight * wt$tau_within) - fit0$tau) < 1e-10)
## separability check: boundary-by-boundary estimation reproduces the pooled weights
sep <- bind_rows(lapply(bnds, function(b) {f <- fe_fit(d0[d0$boundary_id == b, ]); tibble(boundary_id = b, tau_sep = f$tau)}))
wt <- wt |> left_join(sep, by = "boundary_id")
stopifnot(max(abs(wt$tau_sep - wt$tau_within)) < 1e-8)
write_csv(wt, file.path(OUT, "ext_estimatorB_implied_weights.csv"))
h500 <- setNames(rep(500, length(bnds)), bnds); h2000 <- setNames(rep(2000, length(bnds)), bnds)
windows <- bind_rows(H0, headline(in_bandwidth(pan, h500), "Common 500 m window"),
                     headline(in_bandwidth(pan, h2000), "Full 2,000 m window"))
write_csv(windows, file.path(OUT, "ext_estimatorB_windows.csv"))
message("[10] E3 done")

## =============================================================================
## E4 heterogeneity by date-level characteristics
## =============================================================================
het_one <- function(d, H, label, lab0, lab1) {
  X <- cbind(D = d$rationed, DH = d$rationed * H)
  f <- fe_multi(d, X); V <- cluster_vcov_multi(f, d$cycle_id)
  b0 <- f$beta[1]; b1 <- f$beta[1] + f$beta[2]
  se0 <- sqrt(V[1, 1]); se1 <- sqrt(V[1, 1] + V[2, 2] + 2 * V[1, 2]); sed <- sqrt(V[2, 2])
  m0 <- mean(d$n[d$rationed == 0L & H == 0]); m1 <- mean(d$n[d$rationed == 0L & H == 1])
  tibble(dimension = label, group = c(lab0, lab1, "Difference"),
         estimate = c(b0, b1, f$beta[2]), se_cycle9 = c(se0, se1, sed),
         control_mean = c(m0, m1, NA_real_),
         n_dates = c(n_distinct(d$analysis_date[H == 0]), n_distinct(d$analysis_date[H == 1]), NA)) |>
    mutate(ci_lo = estimate - 1.96 * se_cycle9, ci_hi = estimate + 1.96 * se_cycle9,
           p_value = 2 * pnorm(-abs(estimate / se_cycle9)), pct_of_control = 100 * estimate / control_mean)
}
dow <- as.POSIXlt(d0$analysis_date)$wday
het <- bind_rows(
  het_one(d0, as.integer(d0$analysis_date >= ALT_START & d0$analysis_date <= ALT_END),
          "Rationing frequency", "Daily phase", "Alternate-day phase"),
  het_one(d0, as.integer(d0$cycle_id > 17L), "Programme half", "Cycles 1-17", "Cycles 18-34"),
  het_one(d0, as.integer(dow %in% c(0L, 6L)), "Day of week", "Weekday water day", "Weekend water day"))
write_csv(het, file.path(OUT, "ext_heterogeneity.csv"))
message("[10] E4 done")

## =============================================================================
## E5 placebos on the primary specification
## =============================================================================
## (a) displaced cutoffs, Estimator A, operational panel (logic of 04)
cluster_vcov <- function(X, u, w, cl) {
  bread <- solve(crossprod(X * sqrt(w))); meat <- matrix(0, ncol(X), ncol(X))
  for (g in split(seq_along(u), cl)) {s <- crossprod(X[g, , drop = FALSE], w[g] * u[g]); meat <- meat + tcrossprod(s)}
  Gc <- length(unique(cl)); N <- length(u); K <- ncol(X)
  bread %*% meat %*% bread * (Gc / (Gc - 1)) * ((N - 1) / (N - K))
}
ll_disc <- function(y, xx, h, cl) {
  k <- abs(xx) < h; if (sum(k) < 20) return(NULL)
  y <- y[k]; xx <- xx[k]; cl <- cl[k]; w <- 1 - abs(xx) / h; Dd <- as.numeric(xx < 0)
  if (all(Dd == 1) || all(Dd == 0)) return(NULL)
  X <- cbind(1, Dd, xx, xx * Dd)
  b <- tryCatch(solve(crossprod(X * sqrt(w)), crossprod(X, w * y)), error = function(e) NULL)
  if (is.null(b)) return(NULL)
  u <- as.numeric(y - X %*% b); V <- cluster_vcov(X, u, w, cl)
  c(tau = b[2], se = sqrt(V[2, 2]), n = sum(k))
}
act <- pan |> filter(active == 1L)
AW <- pan |> distinct(boundary_id, cell_id, mag, area_m2) |> filter(mag < as.numeric(Hb[boundary_id])) |>
  group_by(boundary_id) |> summarise(area = sum(area_m2), .groups = "drop")
AW <- setNames(AW$area, AW$boundary_id)
pool_area <- function(e) {w <- AW[e$boundary_id]; c(tau = sum(w * e$tau) / sum(w), se = sqrt(sum(w^2 * e$se^2)) / sum(w))}
placebo_at <- function(dd) {
  half <- min(abs(dd), 2000 - abs(dd)); if (half < 100) return(NULL)
  e <- bind_rows(lapply(bnds, function(b) {
    s <- act[act$boundary_id == b, ]; s <- if (dd > 0) s[s$rationed == 0L, ] else s[s$rationed == 1L, ]
    if (!nrow(s)) return(NULL)
    x <- if (dd > 0) s$mag else -s$mag
    r <- ll_disc(s$n, x - dd, min(half, Hb[[b]]), s$analysis_date); if (is.null(r)) return(NULL)
    tibble(boundary_id = b, tau = r[["tau"]], se = r[["se"]])
  }))
  if (!nrow(e)) return(NULL); p <- pool_area(e)
  tibble(shift_m = dd, tau = p[["tau"]], se = p[["se"]], z = p[["tau"]] / p[["se"]], n_boundaries = nrow(e))
}
true_e <- bind_rows(lapply(bnds, function(b) {
  s <- act[act$boundary_id == b, ]; x <- ifelse(s$rationed == 1L, -s$mag, s$mag)
  r <- ll_disc(s$n, x, Hb[[b]], s$analysis_date); tibble(boundary_id = b, tau = r[["tau"]], se = r[["se"]])
}))
TP <- pool_area(true_e)
pre_op <- bind_rows(lapply(c(-750, -500, -250, 250, 500, 750), placebo_at)) |> mutate(p = 2 * pnorm(-abs(z)))
dense_op <- bind_rows(lapply(setdiff(seq(-1750, 1750, by = 50), c(-50, 0, 50)), placebo_at)) |> mutate(p = 2 * pnorm(-abs(z)))
write_csv(pre_op, file.path(OUT, "ext_placebo_displaced_operational.csv"))
write_csv(dense_op, file.path(OUT, "ext_placebo_dense_operational.csv"))

## (b) shift-label permutations of Estimator B (boundary-by-date FE, bandwidths)
ends <- adj |> select(boundary_id, shift_a, shift_b)
pb <- pan |> filter(mag < as.numeric(Hb[boundary_id])) |> left_join(ends, by = "boundary_id") |>
  mutate(own_shift = as.integer(p2s[as.character(polygon_id)]))
tauB_for <- function(map) {
  z <- pb[map[pb$shift_a] == pb$shift | map[pb$shift_b] == pb$shift, ]
  z$rationed <- as.integer(map[z$own_shift] == z$shift)
  f <- fe_fit(z); if (is.null(f)) NA_real_ else f$tau
}
tau_id <- tauB_for(1:9); stopifnot(abs(tau_id - fit0$tau) < 1e-10)
set.seed(20240411L)
permB <- vapply(seq_len(N_PERM), function(i) tauB_for(sample(9)), numeric(1)); permB <- permB[is.finite(permB)]
perm_sum <- tibble(quantity = c("tau_observed", "n_permutations", "percentile", "share_at_least_as_extreme", "permutation_sd",
                                "displaced_true_tau", "displaced_true_se", "dense_n", "dense_sd", "dense_share_more_extreme",
                                "dense_nominal_rejection_rate", "fixed_displacement_rejections"),
                   value = c(tau_id, length(permB), 100 * mean(permB <= tau_id),
                             (1 + sum(abs(permB) >= abs(tau_id))) / (1 + length(permB)), sd(permB),
                             TP[["tau"]], TP[["se"]], nrow(dense_op), sd(dense_op$tau),
                             mean(abs(dense_op$tau) >= abs(TP[["tau"]])), mean(dense_op$p < .05), sum(pre_op$p < .05)))
write_csv(tibble(draw = c(0, seq_along(permB)), tau = c(tau_id, permB)), file.path(OUT, "ext_placebo_permutations_estimatorB.csv"))
write_csv(perm_sum, file.path(OUT, "ext_placebo_summary_operational.csv"))
message("[10] E5 placebos done")

## =============================================================================
## E6 rotation balance: when is each side scheduled?
## =============================================================================
datechar <- function(dts) tibble(weekend = mean(as.POSIXlt(dts)$wday %in% c(0, 6)),
                                 alternate_phase = mean(dts >= ALT_START & dts <= ALT_END),
                                 mean_date = mean(as.numeric(dts)), n = length(dts))
bal <- bind_rows(lapply(bnds, function(b) {
  z <- pan |> filter(boundary_id == b, active == 1L) |> distinct(side, analysis_date, rationed) |> filter(rationed == 1L)
  da <- z$analysis_date[z$side == "a"]; db <- z$analysis_date[z$side == "b"]
  wa <- table(factor(as.POSIXlt(da)$wday, 0:6)); wb <- table(factor(as.POSIXlt(db)$wday, 0:6))
  chi <- suppressWarnings(chisq.test(rbind(wa, wb)))
  ca <- datechar(da); cb <- datechar(db)
  tibble(boundary_id = b, dates_a = ca$n, dates_b = cb$n,
         weekend_share_a = ca$weekend, weekend_share_b = cb$weekend,
         alt_phase_share_a = ca$alternate_phase, alt_phase_share_b = cb$alternate_phase,
         mean_date_gap_days = ca$mean_date - cb$mean_date, weekday_chisq_p = chi$p.value)
}))
write_csv(bal, file.path(OUT, "ext_rotation_balance.csv"))
message("[10] E6 done")

## =============================================================================
## E7 drop water days adjacent to citywide-silent calendar dates
## =============================================================================
silent <- as.Date(c("2024-05-14", "2024-05-15", "2024-08-06", "2024-11-18", "2024-12-18", "2025-01-17", "2025-01-18"))
touch <- unique(c(silent, silent - 1L))
d7 <- d0 |> filter(!analysis_date %in% touch)
E7 <- headline(d7, "Excluding water days touching silent calendar dates") |>
  mutate(dates_removed = n_distinct(d0$analysis_date) - n_distinct(d7$analysis_date))
write_csv(E7, file.path(OUT, "ext_silent_days_excluded.csv"))

## =============================================================================
## E8 reconciliation
## =============================================================================
recon <- tibble(
  quantity = c("placements_operational_all_cells_dates", "placements_calendar_all_cells_dates",
               "usable_dates_operational", "usable_dates_calendar", "schedule_dates",
               "operational_dates_missing", "calendar_dates_missing", "rotation_cycles_operational"),
  value = c(sum(pan$n), sum(pcal$n), n_distinct(pan$analysis_date), n_distinct(pcal$analysis_date), nrow(cal),
            paste(format(sort(setdiff(cal$date, unique(pan$analysis_date)))), collapse = ";"),
            paste(format(sort(setdiff(cal$date, unique(pcal$analysis_date)))), collapse = ";"),
            n_distinct(pan$cycle_id)))
write_csv(recon, file.path(OUT, "ext_reconciliation.csv"))

## =============================================================================
## E9 active boundaries per polygon-day (public inputs only)
## A boundary is active on a date if either adjoining polygon belongs to the
## rationed shift. A rationed polygon activates all of its boundaries; a polygon
## that is a comparison activates only those adjoining the rationed shift. The
## counts below show why assigning each report to its nearest ACTIVE boundary
## would make cell contents depend on treatment (Section 4.9).
## =============================================================================
adj9 <- adj |> transmute(boundary_id, p1 = poly_a, p2 = poly_b)
nb9 <- bind_rows(adj9 |> transmute(boundary_id, polygon_id = p1, other = p2),
                 adj9 |> transmute(boundary_id, polygon_id = p2, other = p1))
act <- tidyr::crossing(polygon_id = xw$polygon_id, date = cal$date) |>
  left_join(cal |> select(date, rationed_shift = shift), by = "date") |>
  left_join(nb9, by = "polygon_id", relationship = "many-to-many") |>
  mutate(own_rationed = as.integer(p2s[as.character(polygon_id)] == rationed_shift),
         other_rationed = as.integer(p2s[as.character(other)] == rationed_shift),
         is_active = own_rationed == 1L | other_rationed == 1L) |>
  group_by(polygon_id, date, own_rationed) |>
  summarise(n_active = sum(is_active), .groups = "drop") |>
  filter(n_active > 0)
E9 <- bind_rows(
  act |> group_by(group = ifelse(own_rationed == 1L, "rationed", "comparison")) |>
    summarise(mean_active_boundaries = mean(n_active), polygon_days = n(), .groups = "drop"),
  tibble(group = "correlation_with_treatment",
         mean_active_boundaries = cor(act$own_rationed, act$n_active),
         polygon_days = nrow(act)))
write_csv(E9, file.path(OUT, "ext_active_boundary_counts.csv"))
message("[10] E9 done")
message("[10] additional analyses complete")
