#!/usr/bin/env Rscript
## ---------------------------------------------------------------------------
## 00_master.R -- complete public replication and optional restricted rebuild
##
## Public path (default):
##   Rscript code/00_master.R
##
## Restricted rebuild (authorised users only):
##   INPUT_ROOT=/path/to/project/data \
##   INCIDENTS_ALL=/path/to/project/data/raw/NUSE_NGA.dsv \
##   Rscript code/00_master.R --full
##
## The default path reads only staged public inputs and aggregate panels.
## The restricted path rebuilds panels from the raw
## emergency-call extract. All generated files are written below the repository
## root; neither path writes to INPUT_ROOT.
## ---------------------------------------------------------------------------

args <- commandArgs(trailingOnly = TRUE)
full_requested <- "--full" %in% args

repo_root <- normalizePath(".")
Sys.setenv(ROOT = repo_root)
dir.create(file.path(repo_root, "output"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(repo_root, "tables"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(repo_root, "figures"), recursive = TRUE, showWarnings = FALSE)

input_root <- Sys.getenv("INPUT_ROOT", "")
incidents_all <- Sys.getenv("INCIDENTS_ALL", "")
raw_available <- nzchar(input_root) && dir.exists(input_root) &&
  nzchar(incidents_all) && file.exists(incidents_all)

if (full_requested && !raw_available) {
  stop("--full requires valid INPUT_ROOT and INCIDENTS_ALL environment variables.")
}
if (full_requested && xor(nzchar(input_root), nzchar(incidents_all))) {
  stop("Set both INPUT_ROOT and INCIDENTS_ALL, or set neither for public replication.")
}

required_public <- c(
  "data/public/hydraulic_polygons.gpkg",
  "data/public/polygon_shift_crosswalk.csv",
  "data/public/rationing_calendar.csv",
  "data/derived/bandwidths_mserd.csv"
)
if (!full_requested) required_public <- c(required_public,
  "data/derived/cell_exposure_area.csv",
  "data/derived/monthly_maltrato_citywide.csv",
  "data/derived/panel_fixed_geography.csv.gz",
  "data/derived/panel_operational_0800.csv.gz",
  "data/derived/panel_calendar_secondary.csv.gz",
  "data/derived/panel_segments_500m.csv.gz",
  "data/derived/panel_segments_1000m.csv.gz"
)
missing_inputs <- required_public[!file.exists(file.path(repo_root, required_public))]
if (length(missing_inputs)) {
  stop("Missing replication inputs: ", paste(missing_inputs, collapse = ", "))
}

## EAAB Resolución 182 de 2025 lifted rationing at 08:00 on 12 April 2025, so the
## last scheduled water day begins on 11 April. The check below guards against
## schedule assignments after the lift.
schedule_dates <- as.Date(read.csv(file.path(repo_root,
  "data/public/rationing_calendar.csv"))$date)
if (anyNA(schedule_dates) || anyDuplicated(schedule_dates) ||
    min(schedule_dates) != as.Date("2024-04-11") ||
    max(schedule_dates) != as.Date("2025-04-11") ||
    length(schedule_dates) != 306L) {
  stop("Rationing calendar does not match the official 11 April 2025 last shift (306 assignments).")
}

needed_packages <- c("dplyr", "readr", "tidyr", "sf", "ggplot2", "fixest", "tibble")
if (full_requested) needed_packages <- c(needed_packages, "lwgeom")
missing_packages <- needed_packages[
  !vapply(needed_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages)) {
  stop("Install missing R packages before running: ", paste(missing_packages, collapse = ", "))
}

run <- function(script) {
  message("\n>>> ", script)
  source(file.path("code", script), echo = FALSE)
}

run("00a_prepare_geography.R")
run("01_validate_adjacency.R")

if (full_requested) {
  Sys.setenv(INPUT_ROOT = normalizePath(input_root),
             INCIDENTS_ALL = normalizePath(incidents_all))
  message("Restricted path: rebuilding aggregate panels from the configured raw extract.")
  run("02_read_restricted_incidents.R")
  run("03_build_fixed_geography.R")
} else {
  message("Aggregate path: using the shipped derived panels, whose publication is confirmed by the author.")
}

run("04_placebo_checks.R")
run("05_treatment_clocks.R")
run("06_robustness.R")
run("10_additional_analyses.R")
if (full_requested) run("11_restricted_additional_analyses.R")
if (nzchar(Sys.getenv("ADMIN_LAYERS")) || nzchar(Sys.getenv("ESTRATO_LAYER"))) run("12_external_layers.R")
run("07_manuscript_exhibits.R")
run("08_verify_manuscript_numbers.R")

message("\nReplication complete. Statistical outputs are in output/, generated exhibits ",
        "are in tables/ and figures/, and the manuscript-number audit is ",
        "output/manuscript_number_audit.csv.")
