#!/usr/bin/env Rscript
## =============================================================================
## 12_external_layers.R -- boundary overlap, estrato balance and estrato
## heterogeneity, using public Bogotá layers that are not shipped here.
##
## Inputs (environment variables; any OGR-readable polygon file):
##   ADMIN_LAYERS   semicolon-separated "label=path" pairs, for example
##                  "localidad=/data/localidades.gpkg;upz=/data/upz.gpkg"
##   ESTRATO_LAYER  path to block-level (manzana) stratification polygons
##   ESTRATO_FIELD  name of the numeric estrato attribute (default "ESTRATO")
## Either input may be omitted; the corresponding outputs are then skipped.
##
## Outputs (aggregates only):
##   output/ext_boundary_overlap.csv     share of each hydraulic boundary's length
##                                       within 50/100/250 m of an administrative line
##   output/ext_estrato_balance.csv      mean estrato on each side, within bandwidth
##   output/ext_estrato_heterogeneity.csv Estimator B by low/high-estrato cells
## =============================================================================
suppressPackageStartupMessages({library(sf); library(dplyr); library(readr); library(tidyr)})
ROOT <- Sys.getenv("ROOT", "."); DER <- file.path(ROOT, "data", "derived"); OUT <- file.path(ROOT, "output")
ADMIN_LAYERS <- Sys.getenv("ADMIN_LAYERS", ""); ESTRATO_LAYER <- Sys.getenv("ESTRATO_LAYER", "")
ESTRATO_FIELD <- Sys.getenv("ESTRATO_FIELD", "ESTRATO"); GRID_M <- 50; BIN_W <- 50; MAX_D <- 2000
if (!nzchar(ADMIN_LAYERS) && !nzchar(ESTRATO_LAYER)) {message("[12] no external layers configured; skipping"); quit(save = "no")}

adj <- read_csv(file.path(DER, "adjacency_pairs.csv"), show_col_types = FALSE)
bws <- read_csv(file.path(DER, "bandwidths_mserd.csv"), show_col_types = FALSE)
bnds <- sort(unique(adj$boundary_id))
Hb <- setNames(bws$h_mserd[match(bnds, bws$boundary_id)], bnds); Hb[is.na(Hb)] <- median(bws$h_mserd)
poly <- st_read(file.path(DER, "hydraulic_polygons_analysis.gpkg"), quiet = TRUE) |>
  st_zm(drop = TRUE) |> st_make_valid() |> filter(!is.na(polygon_id)) |> arrange(polygon_id)
g <- st_geometry(poly); pid <- poly$polygon_id; gi <- function(k) g[[which(pid == k)]]
lines <- lapply(seq_len(nrow(adj)), function(i) st_union(st_intersection(
  st_boundary(st_sfc(gi(adj$poly_a[i]), crs = 3116)), st_boundary(st_sfc(gi(adj$poly_b[i]), crs = 3116)))))
read_layer <- function(p) st_read(p, quiet = TRUE) |> st_zm(drop = TRUE) |> st_make_valid() |> st_transform(3116)

## ---- boundary overlap ---------------------------------------------------------
if (nzchar(ADMIN_LAYERS)) {
  specs <- strsplit(strsplit(ADMIN_LAYERS, ";", fixed = TRUE)[[1]], "=", fixed = TRUE)
  ov <- bind_rows(lapply(specs, function(s) {
    lab <- s[1]; L <- read_layer(s[2])
    adm <- st_union(st_boundary(st_geometry(L)))
    bind_rows(lapply(seq_len(nrow(adj)), function(i) {
      li <- lines[[i]]; len <- as.numeric(st_length(li))
      bind_rows(lapply(c(50, 100, 250), function(tol) {
        near <- st_intersection(li, st_buffer(adm, tol))
        tibble(layer = lab, boundary_id = adj$boundary_id[i], tolerance_m = tol, boundary_length_m = len,
               share_within_tolerance = if (length(near)) sum(as.numeric(st_length(near))) / len else 0)
      }))
    }))
  }))
  write_csv(ov, file.path(OUT, "ext_boundary_overlap.csv"))
  message("[12] boundary overlap written")
}

## ---- estrato balance and heterogeneity --------------------------------------
if (nzchar(ESTRATO_LAYER)) {
  es <- read_layer(ESTRATO_LAYER)
  if (!ESTRATO_FIELD %in% names(es)) stop("[12] ESTRATO_FIELD not found: ", ESTRATO_FIELD)
  es <- es |> transmute(estrato = suppressWarnings(as.numeric(.data[[ESTRATO_FIELD]]))) |> filter(is.finite(estrato), estrato >= 1, estrato <= 6)
  ## lattice points inside each endpoint polygon, binned exactly as in 03
  cells <- bind_rows(lapply(seq_len(nrow(adj)), function(i) bind_rows(lapply(c("a", "b"), function(sd) {
    k <- if (sd == "a") adj$poly_a[i] else adj$poly_b[i]; pg <- st_sfc(gi(k), crs = 3116); bb <- st_bbox(pg)
    lat <- st_as_sf(expand.grid(x = seq(bb["xmin"], bb["xmax"], by = GRID_M), y = seq(bb["ymin"], bb["ymax"], by = GRID_M)),
                    coords = c("x", "y"), crs = 3116)
    lat <- lat[lengths(st_intersects(lat, pg)) > 0, ]; if (!nrow(lat)) return(NULL)
    d <- as.numeric(st_distance(lat, lines[[i]])); keep <- d < MAX_D; lat <- lat[keep, ]; d <- d[keep]
    lat$pt <- seq_len(nrow(lat))
    j <- st_join(lat, es, join = st_within, left = TRUE) |> st_drop_geometry()
    j <- j[!duplicated(j$pt), ]; j <- j[order(j$pt), ]   # one block per lattice point
    tibble(boundary_id = adj$boundary_id[i], side = sd, polygon_id = k,
           mag = floor(d / BIN_W) * BIN_W + BIN_W / 2, estrato = j$estrato) |>
      group_by(boundary_id, side, polygon_id, mag) |>
      summarise(mean_estrato = mean(estrato, na.rm = TRUE), share_residential = mean(is.finite(estrato)),
                lattice_pts = n(), .groups = "drop")
  }))))
  write_csv(cells, file.path(DER, "cell_estrato.csv"))
  bal <- cells |> filter(mag < as.numeric(Hb[boundary_id])) |>
    group_by(boundary_id, side) |>
    summarise(mean_estrato = weighted.mean(mean_estrato, lattice_pts * share_residential, na.rm = TRUE),
              share_residential = weighted.mean(share_residential, lattice_pts), .groups = "drop") |>
    pivot_wider(names_from = side, values_from = c(mean_estrato, share_residential)) |>
    mutate(estrato_gap_a_minus_b = mean_estrato_a - mean_estrato_b)
  write_csv(bal, file.path(OUT, "ext_estrato_balance.csv"))

  ## Estimator B with a cell-level low-estrato interaction (time-invariant, so
  ## its main effect is absorbed by cell fixed effects)
  src <- readLines(file.path(ROOT, "code", "10_additional_analyses.R"))
  eval(parse(text = src[grep("^demeanK <- function", src):(grep("^in_bandwidth <- function", src) - 1L)]))
  pan <- read_csv(file.path(DER, "panel_operational_0800.csv.gz"), show_col_types = FALSE) |>
    mutate(analysis_date = as.Date(analysis_date)) |>
    filter(active == 1L, mag < as.numeric(Hb[boundary_id])) |>
    left_join(cells |> select(boundary_id, side, mag, mean_estrato), by = c("boundary_id", "side", "mag")) |>
    filter(is.finite(mean_estrato))
  cut <- median(pan$mean_estrato[!duplicated(pan$cell_id)])
  H <- as.integer(pan$mean_estrato <= cut)
  f <- fe_multi(pan, cbind(D = pan$rationed, DH = pan$rationed * H)); V <- cluster_vcov_multi(f, pan$cycle_id)
  het <- tibble(group = c("Higher-estrato cells", "Lower-estrato cells", "Difference"),
                estimate = c(f$beta[1], f$beta[1] + f$beta[2], f$beta[2]),
                se_cycle9 = c(sqrt(V[1, 1]), sqrt(V[1, 1] + V[2, 2] + 2 * V[1, 2]), sqrt(V[2, 2])),
                control_mean = c(mean(pan$n[pan$rationed == 0 & H == 0]), mean(pan$n[pan$rationed == 0 & H == 1]), NA),
                median_cutoff = cut) |>
    mutate(ci_lo = estimate - 1.96 * se_cycle9, ci_hi = estimate + 1.96 * se_cycle9,
           p_value = 2 * pnorm(-abs(estimate / se_cycle9)), pct_of_control = 100 * estimate / control_mean)
  write_csv(het, file.path(OUT, "ext_estrato_heterogeneity.csv"))
  message("[12] estrato balance and heterogeneity written")
}
