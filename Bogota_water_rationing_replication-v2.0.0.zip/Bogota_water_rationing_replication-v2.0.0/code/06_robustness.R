#!/usr/bin/env Rscript
## =============================================================================
## Robustness suite: dynamics, boundary segments, common bandwidth,
## rotation-cycle clustering, and PPML.  The operational clock is primary.
## =============================================================================
HAS_RAW <- exists("INC_ALL_SF")
suppressPackageStartupMessages({
  library(sf); library(dplyr); library(readr); library(tidyr); library(fixest)
  if (HAS_RAW) library(lwgeom)
})
fixest::setFixest_nthreads(1L)
ROOT <- Sys.getenv("ROOT", "."); DER <- file.path(ROOT, "data", "derived")
PUB <- file.path(ROOT, "data", "public"); OUT <- file.path(ROOT, "output")
BIN_W <- 50; GRID_M <- 50; COMMON_H <- 500

pan <- read_csv(file.path(DER, "panel_operational_0800.csv.gz"), show_col_types = FALSE) |>
  mutate(analysis_date = as.Date(analysis_date))
adj <- read_csv(file.path(DER, "adjacency_pairs.csv"), show_col_types = FALSE)
bws <- read_csv(file.path(DER, "bandwidths_mserd.csv"), show_col_types = FALSE)
cal <- read_csv(file.path(PUB, "rationing_calendar.csv"), show_col_types = FALSE) |>
  transmute(date = as.Date(date), shift = as.integer(turno_group_id)) |>
  arrange(date) |> mutate(cycle_id = (row_number() - 1L) %/% 9L + 1L)
xw <- read_csv(file.path(PUB, "polygon_shift_crosswalk.csv"), show_col_types = FALSE)
p2s <- setNames(xw$shift_id, as.character(xw$polygon_id))
bnds <- sort(unique(adj$boundary_id)); Hb <- setNames(bws$h_mserd[match(bnds,bws$boundary_id)],bnds)
Hb[is.na(Hb)] <- median(bws$h_mserd)

## Core estimators are defined here as a fallback so this step can also be run
## directly after the operational panel has been built.
if (!exists("demeanK")) demeanK <- function(v, idx, nlev, tol=1e-10, maxit=1000L) {
  v <- as.numeric(v)
  for (iter in seq_len(maxit)) {old <- v; for(j in seq_along(idx))
    v <- v-(rowsum(v,idx[[j]])/tabulate(idx[[j]],nlev[j]))[idx[[j]]]
    if(max(abs(v-old))<tol) break}
  v
}
if (!exists("fe_fit")) fe_fit <- function(d, y=d$n, x=d$rationed) {
  fs<-list(factor(d$cell_id),factor(d$boundary_date_id));idx<-lapply(fs,as.integer)
  nl<-vapply(fs,nlevels,integer(1));yy<-demeanK(y,idx,nl);xx<-demeanK(x,idx,nl)
  den<-sum(xx*xx);tau<-sum(xx*yy)/den
  list(tau=tau,x=xx,residual=yy-tau*xx,den=den,K=sum(nl)+1L,n=nrow(d))
}
if (!exists("cluster_se")) cluster_se <- function(fit,cl) {
  sc<-vapply(split(seq_along(cl),cl),function(ii)sum(fit$x[ii]*fit$residual[ii]),numeric(1));G<-length(sc)
  sqrt(sum(sc^2)/fit$den^2*(G/(G-1))*((fit$n-1)/(fit$n-fit$K)))
}
if (!exists("fit_A")) {
  rd_A <- function(d,h) {
    d<-d[d$mag<h,];x<-ifelse(d$rationed==1L,-d$mag,d$mag);w<-1-abs(x)/h;D<-as.numeric(x<0)
    X<-cbind(1,D,x,x*D);bb<-solve(crossprod(X*sqrt(w)),crossprod(X,w*d$n));u<-as.numeric(d$n-X%*%bb)
    bread<-solve(crossprod(X*sqrt(w)));meat<-matrix(0,4,4)
    for(ii in split(seq_along(u),d$analysis_date)){sc<-crossprod(X[ii,,drop=FALSE],w[ii]*u[ii]);meat<-meat+tcrossprod(sc)}
    G<-n_distinct(d$analysis_date);N<-nrow(d);V<-bread%*%meat%*%bread*(G/(G-1))*((N-1)/(N-4))
    cells<-d[!duplicated(d$cell_id),];c(tau=bb[2],se=sqrt(V[2,2]),n_inc=sum(d$n),area_km2=sum(cells$area_m2)/1e6)
  }
  fit_A <- function(p,hvec) bind_rows(lapply(bnds,function(b){z<-rd_A(p|>filter(active==1L,boundary_id==b),hvec[[b]])
    tibble(boundary_id=b,tau=z[["tau"]],se=z[["se"]],n_inc=z[["n_inc"]],area_km2=z[["area_km2"]],bandwidth=hvec[[b]])}))
  pool_A <- function(z){w<-z$area_km2/sum(z$area_km2);c(tau=sum(w*z$tau),se=sqrt(sum(w^2*z$se^2)),max_weight=max(w))}
}

## ---- multi-regressor absorbed OLS and clustered covariance ------------------
fe_multi <- function(d, X) {
  fs <- list(factor(d$cell_id), factor(d$boundary_date_id)); idx <- lapply(fs, as.integer)
  nl <- vapply(fs, nlevels, integer(1)); yd <- demeanK(d$n, idx, nl)
  Xd <- apply(as.matrix(X), 2, demeanK, idx = idx, nlev = nl)
  if (is.null(dim(Xd))) Xd <- matrix(Xd, ncol = 1)
  keep <- apply(Xd, 2, function(z) sum(z^2) > 1e-12); Xd <- Xd[,keep,drop=FALSE]
  bread <- solve(crossprod(Xd)); beta <- as.numeric(bread %*% crossprod(Xd, yd))
  u <- as.numeric(yd - Xd %*% beta)
  list(beta=beta, X=Xd, u=u, bread=bread, K=sum(nl)+ncol(Xd), n=nrow(d), keep=keep)
}
cluster_vcov_multi <- function(fit, cl) {
  meat <- matrix(0, ncol(fit$X), ncol(fit$X))
  for (ii in split(seq_along(cl), cl)) {
    sc <- crossprod(fit$X[ii,,drop=FALSE], fit$u[ii]); meat <- meat + tcrossprod(sc)
  }
  G <- n_distinct(cl)
  fit$bread %*% meat %*% fit$bread * (G/(G-1)) * ((fit$n-1)/(fit$n-fit$K))
}

## ---- event time: nearest scheduled water day for the cell's shift -----------
nearest_event <- function(d, shift) {
  ev <- cal$date[cal$shift == shift]
  vapply(d, function(day) {
    delta <- as.integer(day - ev); delta[which.min(abs(delta))]
  }, integer(1))
}
pd <- pan |> distinct(polygon_id, analysis_date) |>
  mutate(own_shift = as.integer(p2s[as.character(polygon_id)]),
         event_time = mapply(nearest_event, analysis_date, own_shift))
dyn <- pan |> left_join(pd |> select(polygon_id, analysis_date, event_time),
                        by=c("polygon_id","analysis_date")) |>
  ## Dynamics use every observed operational date, including dates on which
  ## neither endpoint of a particular boundary is rationed.  This supplies a
  ## genuine outside-window reference category rather than comparing leads and
  ## lags only with the currently rationed side.
  filter(mag < as.numeric(Hb[boundary_id]))
ks <- -2:2
Xev <- sapply(ks, function(k) as.integer(dyn$event_time == k))
colnames(Xev) <- paste0("k", ifelse(ks < 0, "m", "p"), abs(ks))
fd <- fe_multi(dyn, Xev); Vd <- cluster_vcov_multi(fd, dyn$cycle_id)
event_res <- tibble(event_time=ks[fd$keep], estimate=fd$beta,
                    se_cycle9=sqrt(diag(Vd)),
                    ci_lo=fd$beta-1.96*sqrt(diag(Vd)), ci_hi=fd$beta+1.96*sqrt(diag(Vd)))
lead_ix <- which(event_res$event_time < 0)
lead_wald <- as.numeric(t(fd$beta[lead_ix]) %*% solve(Vd[lead_ix,lead_ix,drop=FALSE]) %*% fd$beta[lead_ix])
dynamic_tests <- tibble(test="Joint test: k=-2 and k=-1", statistic=lead_wald,
                        df=length(lead_ix), p_value=pchisq(lead_wald,length(lead_ix),lower.tail=FALSE))
Xcum <- matrix(as.integer(dyn$event_time >= -1L & dyn$event_time <= 1L), ncol=1)
fc <- fe_multi(dyn, Xcum); Vc <- cluster_vcov_multi(fc, dyn$cycle_id)
cum_res <- tibble(window="[-1,+1]", estimate=fc$beta[1], se_cycle9=sqrt(Vc[1,1]),
                  ci_lo=fc$beta[1]-1.96*sqrt(Vc[1,1]), ci_hi=fc$beta[1]+1.96*sqrt(Vc[1,1]))
write_csv(event_res, file.path(OUT,"dynamic_event_time.csv"))
write_csv(cum_res, file.path(OUT,"dynamic_cumulative.csv"))
write_csv(dynamic_tests, file.path(OUT,"dynamic_tests.csv"))

## Distance profile under the operational clock and cycle-level inference.
dist_res <- bind_rows(lapply(seq(125,1875,by=250),function(mid){
  z <- pan |> filter(active==1L,abs(mag-mid)<=125)
  ff <- fe_fit(z); ss <- cluster_se(ff,z$cycle_id)
  tibble(band_m=mid,estimate=ff$tau,se_cycle9=ss,ci_lo=ff$tau-1.96*ss,ci_hi=ff$tau+1.96*ss)
}))
write_csv(dist_res,file.path(OUT,"distance_profile.csv"))

## ---- common 500 m bandwidth (Estimator A) ---------------------------------
h500 <- setNames(rep(COMMON_H, length(bnds)), bnds)
A500 <- fit_A(pan, h500); P500 <- pool_A(A500)
common_res <- tibble(bandwidth_m=COMMON_H, estimate=P500[["tau"]], se_date=P500[["se"]],
                     ci_lo=P500[["tau"]]-1.96*P500[["se"]],
                     ci_hi=P500[["tau"]]+1.96*P500[["se"]],
                     n_boundaries=nrow(A500), max_area_weight=P500[["max_weight"]])
write_csv(A500, file.path(OUT,"common500_boundary.csv"))
write_csv(common_res, file.path(OUT,"common500_pooled.csv"))

## ---- PPML count specification, with no population offset --------------------
dpp <- pan |> filter(active == 1L, mag < as.numeric(Hb[boundary_id])) |>
  mutate(boundary_date_id=as.factor(boundary_date_id), cell_id=as.factor(cell_id), cycle_id=as.factor(cycle_id))
pp <- fepois(n ~ rationed | cell_id + boundary_date_id, data=dpp,
             vcov=~cycle_id, notes=FALSE, warn=FALSE)
ct <- coeftable(pp); bpp <- unname(coef(pp)["rationed"]); spp <- unname(ct["rationed","Std. Error"])
ppml_res <- tibble(estimate=bpp, se_cycle9=spp, ci_lo=bpp-1.96*spp, ci_hi=bpp+1.96*spp,
                   percent_effect=100*(exp(bpp)-1), n_obs=nobs(pp), n_cells=n_distinct(dpp$cell_id),
                   offset="none") |>
  ## Freeze harmless solver noise below the manuscript's reported precision so
  ## repeated runs produce a byte-identical CSV across clean processes.
  mutate(across(where(is.numeric), ~signif(.x, 12)))
write_csv(ppml_res, file.path(OUT,"ppml.csv"))

## ---- along-boundary segments ------------------------------------------------
poly <- st_read(file.path(DER,"hydraulic_polygons_analysis.gpkg"),quiet=TRUE) |>
  st_zm(drop=TRUE) |> st_make_valid() |> filter(!is.na(polygon_id)) |> arrange(polygon_id)
gg <- st_geometry(poly); pids <- poly$polygon_id; gi2 <- function(k) gg[[which(pids==k)]]
line_for <- function(i) st_union(st_intersection(
  st_boundary(st_sfc(gi2(adj$poly_a[i]),crs=3116)),
  st_boundary(st_sfc(gi2(adj$poly_b[i]),crs=3116))))

cut_line <- function(line, boundary, width) {
  typ <- as.character(st_geometry_type(line)[1])
  if (typ == "GEOMETRYCOLLECTION") {
    line <- st_collection_extract(line, "LINESTRING")
  }
  ## Combine digitised fragments, merge contiguous pieces, then split only true
  ## disconnected components.  Without this step tiny vertex fragments would be
  ## mistaken for substantive along-boundary segments.
  merged <- st_line_merge(suppressWarnings(st_cast(st_combine(line), "MULTILINESTRING")))
  comps <- suppressWarnings(st_cast(merged, "LINESTRING"))
  out <- list(); id <- 0L
  for (j in seq_along(comps)) {
    one <- st_sfc(comps[[j]], crs=3116); L <- as.numeric(st_length(one))
    if (!is.finite(L) || L <= 0) next
    starts <- seq(0, max(L-1e-7,0), by=width)
    for (a in starts) {
      id <- id+1L
      geom <- st_linesubstring(one, from=a/L, to=min(1,(a+width)/L))
      out[[length(out)+1L]] <- st_sf(boundary_id=boundary, segment_id=id, geometry=geom)
    }
  }
  do.call(rbind,out)
}

build_segment_panel <- function(width) {
  message("[06] building ",width," m along-boundary segments")
  panels <- list()
  inc <- INC_ALL_SF |> mutate(water_day=date-as.integer(hour<8L)) |>
    filter(water_day %in% cal$date)
  available <- sort(cal$date[cal$date %in% unique(inc$water_day)])
  sch <- cal |> filter(date %in% available) |> rename(analysis_date=date)
  for (i in seq_len(nrow(adj))) {
    b <- adj$boundary_id[i]; line <- line_for(i); seg <- cut_line(line,b,width)
    endpoints <- c(adj$poly_a[i],adj$poly_b[i])
    ii <- which(inc$polygon_id %in% endpoints)
    dst <- as.numeric(st_distance(inc[ii,],line)); keep <- which(dst<COMMON_H)
    cnt <- NULL
    if (length(keep)) {
      use <- ii[keep]; near <- st_nearest_feature(inc[use,],seg)
      cnt <- tibble(analysis_date=inc$water_day[use],polygon_id=inc$polygon_id[use],
                    segment_id=seg$segment_id[near],mag=floor(dst[keep]/BIN_W)*BIN_W+BIN_W/2) |>
        count(analysis_date,polygon_id,segment_id,mag,name="n")
    }
    ar <- bind_rows(lapply(endpoints,function(k){
      pg <- st_sfc(gi2(k),crs=3116); bb <- st_bbox(pg)
      lat <- st_as_sf(expand.grid(x=seq(bb["xmin"],bb["xmax"],by=GRID_M),
                                  y=seq(bb["ymin"],bb["ymax"],by=GRID_M)),
                     coords=c("x","y"),crs=3116)
      lat <- lat[lengths(st_intersects(lat,pg))>0,]; if (!nrow(lat)) return(NULL)
      dd <- as.numeric(st_distance(lat,line)); take <- which(dd<COMMON_H); if (!length(take)) return(NULL)
      near <- st_nearest_feature(lat[take,],seg)
      tibble(polygon_id=k,segment_id=seg$segment_id[near],
             mag=floor(dd[take]/BIN_W)*BIN_W+BIN_W/2) |>
        count(polygon_id,segment_id,mag,name="lattice_pts") |>
        mutate(area_m2=lattice_pts*GRID_M^2)
    }))
    cells <- ar |> group_by(segment_id) |> filter(n_distinct(polygon_id)==2L) |> ungroup() |>
      mutate(boundary_id=b,side=if_else(polygon_id==adj$poly_a[i],"a","b"))
    if (!nrow(cells)) next
    panels[[length(panels)+1L]] <- cells |> crossing(sch) |>
      mutate(rationed=as.integer(p2s[as.character(polygon_id)]==shift),
             active=as.integer(shift %in% c(adj$shift_a[i],adj$shift_b[i]))) |>
      left_join(cnt,by=c("analysis_date","polygon_id","segment_id","mag")) |>
      mutate(n=coalesce(n,0L),
             cell_id=paste(b,segment_id,side,mag,sep="|"),
             boundary_date_id=paste(b,segment_id,analysis_date,sep="|"))
  }
  bind_rows(panels)
}

coverage_for <- function(d,label) d |> group_by(polygon_id) |>
  summarise(n_rows=n(),n_incidents=sum(n),n_boundaries=n_distinct(boundary_id),
            .groups="drop") |> mutate(specification=label,.before=1)
segment_coverage <- list()
seg_results <- bind_rows(lapply(c(500L,1000L),function(w){
  if (HAS_RAW) {
    z <- build_segment_panel(w)
    write_csv(z,file.path(DER,paste0("panel_segments_",w,"m.csv.gz")))
  } else {
    message("[06] public path: loading shipped ", w, " m segment panel")
    z <- read_csv(file.path(DER,paste0("panel_segments_",w,"m.csv.gz")), show_col_types=FALSE) |>
      mutate(analysis_date=as.Date(analysis_date))
  }
  if (any(!z$analysis_date %in% cal$date))
    stop("Along-boundary panel contains a date outside the official rationing calendar.")
  za <- z |> filter(active==1L); ff <- fe_fit(za); se <- cluster_se(ff,za$cycle_id)
  segment_coverage[[as.character(w)]] <<- coverage_for(za,paste0("segments_",w,"m"))
  ## Use reporting precision below harmless integer/double summation differences
  ## between the in-memory restricted build and CSV-loaded public path.
  base <- signif(mean(za$n[za$rationed==0L]),10)
  tibble(segment_length_m=w,estimate=ff$tau,se_cycle9=se,
         ci_lo=ff$tau-1.96*se,ci_hi=ff$tau+1.96*se,n_rows=nrow(za),
         n_cells=n_distinct(za$cell_id),n_segments=n_distinct(paste(za$boundary_id,za$segment_id)),
         n_incidents=sum(za$n),control_mean=base,
         percent_of_control=signif(100*ff$tau/base,10))
}))
write_csv(seg_results,file.path(OUT,"along_boundary_segments.csv"))

## Coverage is checked in the actual primary estimating sample, after activity
## and bandwidth restrictions, rather than only in the input polygon layer.
coverage <- pan |> filter(active==1L,mag<as.numeric(Hb[boundary_id])) |>
  group_by(polygon_id) |>
  summarise(n_rows=n(),n_incidents=sum(n),n_boundaries=n_distinct(boundary_id),
            .groups="drop") |> arrange(polygon_id)
stopifnot(nrow(coverage)==12L,
          all(coverage$n_rows[coverage$polygon_id %in% c(6L,7L)]>0L),
          all(coverage$n_incidents[coverage$polygon_id %in% c(6L,7L)]>0L))
write_csv(coverage,file.path(OUT,"polygon_estimation_coverage.csv"))
secondary_panel <- read_csv(file.path(DER,"panel_calendar_secondary.csv.gz"),show_col_types=FALSE)
coverage_models <- bind_rows(
  coverage |> mutate(specification="primary_operational",.before=1),
  coverage_for(secondary_panel |> filter(active==1L,mag<as.numeric(Hb[boundary_id])),"secondary_calendar"),
  coverage_for(dyn,"dynamic_and_cumulative"),
  coverage_for(pan |> filter(active==1L,mag<COMMON_H),"common_500m"),
  coverage_for(dpp[fixest::obs(pp),],"PPML_estimation_sample"),
  bind_rows(segment_coverage)) |> arrange(specification,polygon_id)
check_models <- coverage_models |> group_by(specification) |>
  summarise(n_polygons=n_distinct(polygon_id),all_positive_rows=all(n_rows>0),.groups="drop")
stopifnot(all(check_models$n_polygons==12L),all(check_models$all_positive_rows))
write_csv(coverage_models,file.path(OUT,"polygon_coverage_by_model.csv"))
repaired <- read_csv(file.path(OUT,"boundary_estimates_operational.csv"),
                     show_col_types=FALSE) |>
  filter(boundary_id %in% c("2_7","6_11","7_8","7_11"))
stopifnot(nrow(repaired)==4L)
write_csv(repaired,file.path(OUT,"repaired_edge_estimates.csv"))

message("[06] dynamic effects:"); print(event_res)
message("[06] cumulative window:"); print(cum_res)
message("[06] common 500 m aggregation:"); print(common_res)
message("[06] PPML:"); print(ppml_res)
message("[06] segment models:"); print(seg_results)
