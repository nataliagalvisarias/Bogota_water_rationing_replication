#!/usr/bin/env Rscript
## =============================================================================
## 03_build_fixed_geography.R
##
## Builds the estimation sample with an assignment rule that depends ONLY on
## fixed physical geography.
##
## -----------------------------------------------------------------------------
## WHY THE RULE MUST BE TIME-INVARIANT
## -----------------------------------------------------------------------------
## Assigning each incident to its nearest ACTIVE boundary would make cell
## contents depend on the calendar: a rationed polygon activates all of its
## boundaries at once, a comparison polygon only the one adjoining the rationed
## shift. The same incidents would then be divided across more boundaries on
## rationed days than on comparison days, so per-boundary counts would fall
## mechanically under treatment. The rule below avoids this; the diagnostic at
## the end of this script confirms that cell contents do not depend on activity.
##
## -----------------------------------------------------------------------------
## ASSIGNMENT RULE
## -----------------------------------------------------------------------------
## For each of the twenty boundaries b = (p, q):
##   an incident enters b's panel if and only if
##     (i)  it lies in polygon p or polygon q, and
##     (ii) it is within MAX_D metres of the boundary LINE of b.
## Its side is the polygon that contains it. Neither condition mentions the
## calendar, so the assignment rule is time-invariant while treatment labels
## rotate. An incident near a corner enters more than one boundary's
## panel, which is correct -- it genuinely is near more than one boundary -- and
## the resulting overlap is handled in inference rather than by a rule that leaks
## treatment into the outcome. Cell geometry and potential boundary membership
## are time-invariant; reported incident counts can, of course, vary by date.
##
## The pool is the full citywide domestic-violence layer for the legal rationing
## window; no screen conditions on proximity to an active boundary.
##
## -----------------------------------------------------------------------------
## EXPOSURE
## -----------------------------------------------------------------------------
## Each cell's habitable-area exposure is computed from geometry alone by
## sampling a regular GRID_M metre lattice inside each polygon and binning the
## lattice points by distance to the boundary line. Area = points x GRID_M^2.
## This gives a pre-outcome exposure-area weight for pooling. Neither the linear
## count model nor PPML uses a population or area offset.
##
## DISCLOSURE NOTE. This script reads incident-level records and writes only
## aggregates. The incident layer must live outside the replication package;
## the author confirms publication of these aggregates is permitted as of
## 2026-10-27. The raw extract remains excluded. See docs/DATA_ACCESS.md.
## =============================================================================

suppressPackageStartupMessages({
  library(sf); library(dplyr); library(readr); library(tidyr)
})
ROOT <- Sys.getenv("ROOT", "."); DER <- file.path(ROOT,"data","derived")
PUB  <- file.path(ROOT,"data","public"); OUT <- file.path(ROOT,"output")
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)

BIN_W <- 50; MAX_D <- 2000; GRID_M <- 50
MAGS  <- seq(BIN_W/2, MAX_D - BIN_W/2, by = BIN_W)
EDGES <- seq(0, MAX_D, by = BIN_W)

## ---- inputs ------------------------------------------------------------------
poly <- st_read(file.path(DER,"hydraulic_polygons_analysis.gpkg"), quiet = TRUE) |>
  st_zm(drop = TRUE) |> st_make_valid() |>
  filter(!is.na(polygon_id)) |> arrange(polygon_id)
stopifnot(st_crs(poly)$epsg == 3116)

adj <- read_csv(file.path(DER,"adjacency_pairs.csv"), show_col_types = FALSE)
stopifnot(nrow(adj) == 20, all(c(6L,7L) %in% c(adj$poly_a,adj$poly_b)))
cal <- read_csv(file.path(PUB,"rationing_calendar.csv"), show_col_types = FALSE) |>
  transmute(date = as.Date(date), shift = as.integer(turno_group_id))
xw  <- read_csv(file.path(PUB,"polygon_shift_crosswalk.csv"), show_col_types = FALSE)
p2s <- setNames(xw$shift_id, as.character(xw$polygon_id))

if (!exists("INC_ALL_SF")) stop("Run 02_read_restricted_incidents.R before step 03.")
inc_sf <- INC_ALL_SF |> filter(date %in% cal$date)
xy <- st_coordinates(inc_sf)
inc <- inc_sf |>
  mutate(x = xy[,1], y = xy[,2]) |>
  st_drop_geometry() |>
  transmute(crime_id, date, polygon_id = as.integer(polygon_id), x, y)
cat(sprintf("[03] citywide DV incidents in window : %s\n", format(nrow(inc), big.mark=",")))

## ---- boundary lines ----------------------------------------------------------
g <- st_geometry(poly); pid <- poly$polygon_id
gi <- function(k) g[[which(pid == k)]]
lines <- lapply(seq_len(nrow(adj)), function(i) {
  a <- st_sfc(gi(adj$poly_a[i]), crs = 3116); b <- st_sfc(gi(adj$poly_b[i]), crs = 3116)
  st_union(st_intersection(st_boundary(a), st_boundary(b)))
})
names(lines) <- adj$boundary_id
cat(sprintf("[03] boundary lines built            : %d\n", length(lines)))

## ---- distances, incident to each boundary line -------------------------------
pts <- st_as_sf(inc, coords = c("x","y"), crs = 3116)
assign_rows <- bind_rows(lapply(seq_len(nrow(adj)), function(i) {
  b <- adj$boundary_id[i]; p <- adj$poly_a[i]; q <- adj$poly_b[i]
  sel <- which(inc$polygon_id == p | inc$polygon_id == q)
  if (!length(sel)) return(NULL)
  d <- as.numeric(st_distance(pts[sel, ], lines[[i]]))
  keep <- which(d < MAX_D)
  if (!length(keep)) return(NULL)
  tibble::tibble(boundary_id = b,
                 crime_id = inc$crime_id[sel][keep],
                 date = inc$date[sel][keep],
                 polygon_id = inc$polygon_id[sel][keep],
                 dist = d[keep],
                 mag = floor(d[keep]/BIN_W)*BIN_W + BIN_W/2)
}))
cat(sprintf("[03] incident-boundary placements     : %s (unique incidents %s)\n",
            format(nrow(assign_rows), big.mark=","),
            format(n_distinct(assign_rows$crime_id), big.mark=",")))
cat(sprintf("[03] mean boundaries per placed incident: %.3f\n",
            nrow(assign_rows)/n_distinct(assign_rows$crime_id)))

## ---- exposure area per cell, from geometry alone -----------------------------
cat("[03] computing exposure areas by lattice sampling ...\n")
area_rows <- bind_rows(lapply(seq_len(nrow(adj)), function(i) {
  b <- adj$boundary_id[i]
  bind_rows(lapply(c(adj$poly_a[i], adj$poly_b[i]), function(k) {
    pg <- st_sfc(gi(k), crs = 3116)
    bb <- st_bbox(pg)
    xs <- seq(bb["xmin"], bb["xmax"], by = GRID_M)
    ys <- seq(bb["ymin"], bb["ymax"], by = GRID_M)
    lat <- st_as_sf(expand.grid(x = xs, y = ys), coords = c("x","y"), crs = 3116)
    lat <- lat[lengths(st_intersects(lat, pg)) > 0, ]
    if (!nrow(lat)) return(NULL)
    d <- as.numeric(st_distance(lat, lines[[i]]))
    d <- d[d < MAX_D]
    if (!length(d)) return(NULL)
    tibble::tibble(boundary_id = b, polygon_id = k,
                   mag = floor(d/BIN_W)*BIN_W + BIN_W/2) |>
      count(boundary_id, polygon_id, mag, name = "lattice_pts") |>
      mutate(area_m2 = lattice_pts * GRID_M^2)
  }))
}))
cat(sprintf("[03] exposure cells with positive area: %s\n",
            format(nrow(area_rows), big.mark=",")))

## ---- the panel ---------------------------------------------------------------
sides <- bind_rows(
  adj |> transmute(boundary_id, side = "a", polygon_id = poly_a),
  adj |> transmute(boundary_id, side = "b", polygon_id = poly_b))

dates_with_data <- sort(unique(inc$date))
missing_dates <- setdiff(as.character(cal$date), as.character(dates_with_data))
cat(sprintf("[03] study dates with no DV record anywhere (excluded): %d\n",
            length(missing_dates)))
usable <- cal |> filter(!(as.character(date) %in% missing_dates))

skeleton <- sides |>
  crossing(mag = MAGS) |>
  inner_join(area_rows |> select(boundary_id, polygon_id, mag, area_m2),
             by = c("boundary_id","polygon_id","mag")) |>
  crossing(usable |> select(date, shift)) |>
  mutate(rationed = as.integer(p2s[as.character(polygon_id)] == shift))

## a boundary is ACTIVE on a date when exactly one of its two polygons is rationed
act <- skeleton |> group_by(boundary_id, date) |>
  summarise(n_rat = sum(rationed), .groups = "drop") |>
  mutate(active = as.integer(n_rat > 0)) |> select(boundary_id, date, active)

counts <- assign_rows |> count(boundary_id, date, polygon_id, mag, name = "n")

panel <- skeleton |>
  left_join(counts, by = c("boundary_id","date","polygon_id","mag")) |>
  left_join(act, by = c("boundary_id","date")) |>
  mutate(n = coalesce(n, 0L),
         cell_id = paste(boundary_id, side, mag, sep = "|"),
         rate_km2 = n / (area_m2/1e6)) |>
  arrange(boundary_id, date, side, mag)

## time-invariance of cell composition: every cell must appear on every usable date
chk <- panel |> count(cell_id, name = "obs")
stopifnot(length(unique(chk$obs)) == 1)
cat(sprintf("[03] cells x dates                    : %s cells x %d dates = %s rows\n",
            format(n_distinct(panel$cell_id), big.mark=","), n_distinct(panel$date),
            format(nrow(panel), big.mark=",")))
cat(sprintf("[03] incidents in the panel           : %s\n", format(sum(panel$n), big.mark=",")))
cat(sprintf("[03] share of cells empty             : %.1f%%\n", 100*mean(panel$n == 0)))
cat(sprintf("[03] total exposure area              : %.1f km2\n",
            sum(distinct(panel, cell_id, area_m2)$area_m2)/1e6))

write_csv(panel |> select(boundary_id, side, polygon_id, mag, date, active, rationed,
                          n, area_m2, cell_id),
          file.path(DER,"panel_fixed_geography.csv.gz"))
write_csv(area_rows, file.path(DER,"cell_exposure_area.csv"))

## =============================================================================
## DIAGNOSTIC: CELL CONTENTS DO NOT DEPEND ON BOUNDARY ACTIVITY
## =============================================================================
cat("\n=============== ASSIGNMENT-RULE DIAGNOSTIC ===============\n")

## (1) competing active boundaries must not predict cell contents, because
##     cell contents do not depend on activity
pa <- panel |> filter(active == 1) |> distinct(boundary_id, date, polygon_id) |>
  count(date, polygon_id, name = "n_active_at_polygon")
v <- panel |> filter(active == 1) |> left_join(pa, by = c("date","polygon_id"))
cat(sprintf("competing active boundaries: control %.2f, rationed %.2f, corr %.3f\n",
            mean(v$n_active_at_polygon[v$rationed == 0]),
            mean(v$n_active_at_polygon[v$rationed == 1]),
            cor(v$rationed, v$n_active_at_polygon)))
cat("  (this correlation is unchanged by construction -- it is a property of the\n")
cat("   calendar. What matters is whether it moves the OUTCOME:)\n")

## (2) within-polygon comparison of rationed and comparison days
pd <- panel |> filter(active == 1) |> group_by(polygon_id, date, rationed) |>
  summarise(total = sum(n), nb = n_distinct(boundary_id), .groups = "drop")
w <- pd |> group_by(polygon_id) |>
  summarise(tot_r = mean(total[rationed==1]), tot_c = mean(total[rationed==0]),
            pb_r = mean((total/nb)[rationed==1]), pb_c = mean((total/nb)[rationed==0]),
            .groups = "drop") |>
  mutate(d_total = tot_r - tot_c, d_perbnd = pb_r - pb_c)
cat(sprintf("\nwithin-polygon difference, TOTAL across boundaries : %+.2f incidents/day\n",
            mean(w$d_total, na.rm = TRUE)))
cat(sprintf("within-polygon difference, PER BOUNDARY            : %+.2f incidents/day\n",
            mean(w$d_perbnd, na.rm = TRUE)))
cat(sprintf("polygons where the two disagree in sign           : %d of %d\n",
            sum(sign(w$d_total) != sign(w$d_perbnd), na.rm = TRUE), nrow(w)))

## (3) exposure balance across the cutoff
bal <- panel |> distinct(boundary_id, side, mag, area_m2) |>
  group_by(boundary_id) |>
  summarise(area_a = sum(area_m2[side=="a"])/1e6, area_b = sum(area_m2[side=="b"])/1e6,
            ratio = area_a/area_b, .groups = "drop")
cat("\nexposure area by side (km2) and their ratio:\n")
print(as.data.frame(bal |> mutate(across(area_a:ratio, ~round(.x, 2)))), row.names = FALSE)

write_csv(w, file.path(OUT,"within_polygon_assignment_check.csv"))
write_csv(bal, file.path(OUT,"exposure_balance_by_boundary.csv"))
cat("\n[03] wrote panel_fixed_geography.csv.gz and cell_exposure_area.csv\n")
