#!/usr/bin/env Rscript
## Generate the statistical tables and figures of the manuscript from the output
## CSV files: Tables 1--4 and C1--C5; Figures 2--7 and C1. Figures 1, A1, A2 and
## C2 are manually composed QGIS maps supplied in figures/ and are not generated
## here; Figure 2 is drawn from the released monthly citywide counts.
suppressPackageStartupMessages({library(sf);library(dplyr);library(readr);library(ggplot2)})
ROOT<-Sys.getenv("ROOT",".");OUT<-file.path(ROOT,"output");DER<-file.path(ROOT,"data","derived")
TAB<-file.path(ROOT,"tables");FIG<-file.path(ROOT,"figures");dir.create(TAB,recursive=TRUE,showWarnings=FALSE);dir.create(FIG,recursive=TRUE,showWarnings=FALSE)
PURPLE<-"#660099";LILAC<-"#B280CC";GREY<-"grey45"
f<-function(x,d=4)formatC(x,format="f",digits=d);cm<-function(x)formatC(as.integer(round(x)),format="d",big.mark=",")
tim<-read_csv(file.path(OUT,"primary_timing.csv"),show_col_types=FALSE); op<-tim[1,]; ca<-tim[2,]
eb<-read_csv(file.path(OUT,"boundary_estimates_operational.csv"),show_col_types=FALSE)
ev<-read_csv(file.path(OUT,"dynamic_event_time.csv"),show_col_types=FALSE)
cu<-read_csv(file.path(OUT,"dynamic_cumulative.csv"),show_col_types=FALSE)
dt<-read_csv(file.path(OUT,"dynamic_tests.csv"),show_col_types=FALSE)
co<-read_csv(file.path(OUT,"common500_pooled.csv"),show_col_types=FALSE)
sg<-read_csv(file.path(OUT,"along_boundary_segments.csv"),show_col_types=FALSE)
pm<-read_csv(file.path(OUT,"ppml.csv"),show_col_types=FALSE)
dp<-read_csv(file.path(OUT,"distance_profile.csv"),show_col_types=FALSE)
pl<-read_csv(file.path(OUT,"placebo_prespecified_fixed_geo.csv"),show_col_types=FALSE)
pd<-read_csv(file.path(OUT,"placebo_dense_fixed_geo.csv"),show_col_types=FALSE)
pp<-read_csv(file.path(OUT,"placebo_shift_permutations.csv"),show_col_types=FALSE)
ps<-read_csv(file.path(OUT,"placebo_summary_fixed_geo.csv"),show_col_types=FALSE);gs<-function(k)ps$value[ps$quantity==k]
## Additional analyses (10_additional_analyses.R); the primary-specification placebos feed Table 4.
xp<-read_csv(file.path(OUT,"ext_placebo_summary_operational.csv"),show_col_types=FALSE);gx<-function(k)xp$value[xp$quantity==k]
xpre<-read_csv(file.path(OUT,"ext_placebo_displaced_operational.csv"),show_col_types=FALSE)
xden<-read_csv(file.path(OUT,"ext_placebo_dense_operational.csv"),show_col_types=FALSE)
xpb<-read_csv(file.path(OUT,"ext_placebo_permutations_estimatorB.csv"),show_col_types=FALSE)
xw<-read_csv(file.path(OUT,"ext_wild_cluster_bootstrap.csv"),show_col_types=FALSE)
xbl<-read_csv(file.path(OUT,"ext_block_length_sensitivity.csv"),show_col_types=FALSE)
xwin<-read_csv(file.path(OUT,"ext_estimatorB_windows.csv"),show_col_types=FALSE)
xsil<-read_csv(file.path(OUT,"ext_silent_days_excluded.csv"),show_col_types=FALSE)
xev<-read_csv(file.path(OUT,"ext_dynamic_event_time_pm3.csv"),show_col_types=FALSE)
xcu<-read_csv(file.path(OUT,"ext_dynamic_cumulative.csv"),show_col_types=FALSE)
xdt<-read_csv(file.path(OUT,"ext_dynamic_tests_pm3.csv"),show_col_types=FALSE)
xhe<-read_csv(file.path(OUT,"ext_heterogeneity.csv"),show_col_types=FALSE)
xiw<-read_csv(file.path(OUT,"ext_estimatorB_implied_weights.csv"),show_col_types=FALSE)
xrb<-read_csv(file.path(OUT,"ext_rotation_balance.csv"),show_col_types=FALSE)
cuv<-function(m,c)xcu[xcu$window_model==m&xcu$combination==c,]

## Main results: operational clock first.
br<-eb|>arrange(tau)|>transmute(row=sprintf("%s & $%s$ & (%s) & %s & %s \\\\",
  gsub("_","--",boundary_id),f(tau),f(se),cm(n_inc),f(area_km2,1)))
t1<-c("\\begin{table}[htbp]","\\centering",
"\\caption{Primary operational schedule-assignment effects}","\\label{tab:main_results}",
"\\begin{threeparttable}\\footnotesize","\\setlength{\\tabcolsep}{4pt}","\\begin{tabular}{lcccc}","\\toprule",
"Specification / boundary & Effect & Std. err. & Placements & Exposure (km$^2$) \\\\","\\midrule",
"\\multicolumn{5}{l}{\\textit{Panel A: Preferred estimate, cell and boundary $\\times$ date fixed effects}} \\\\",
sprintf("Counts per cell-day & $%s$ & (%s) & %s & \\\\",f(op$tau),f(op$se_cycle9),cm(op$n_incidents)),
sprintf("\\quad 63-analysis-date block bootstrap & & (%s) & \\multicolumn{2}{l}{95\\%% CI $[%s,\\,%s]$} \\\\",f(op$boot_se_63),f(op$ci_lo_63),f(op$ci_hi_63)),"\\midrule",
"\\multicolumn{5}{l}{\\textit{Panel B: Exposure-area aggregation of boundary-specific estimates}} \\\\",
sprintf("Exposure-area weighted & $%s$ & (%s) & & \\\\",f(op$A_tau),f(op$A_se)),"\\midrule",
"\\multicolumn{5}{l}{\\textit{Panel C: Boundary-specific local-linear estimates}} \\\\",br$row,
"\\bottomrule","\\end{tabular}","\\begin{tablenotes}[flushleft]\\small",
sprintf("\\item \\textit{Notes:} The primary treatment clock is 08:00--08:00. The panel has 20 hydraulic boundaries and %s identifying cell-days over %d operational dates. Positive estimates mean scheduled rationing increases reports. Placements are report--boundary placements inside the bandwidths. Panel A uses cell and boundary-by-date fixed effects. Its displayed analytic standard error clusters by nine consecutive rationing assignments; the primary interval resamples 63 consecutive active analysis dates. Panel B uses pre-outcome exposure-area weights; its descriptive pooled standard error combines boundary date-clustered variances without cross-boundary covariance.",cm(op$n_rows),op$n_dates),
"\\end{tablenotes}","\\end{threeparttable}","\\end{table}")
writeLines(t1,file.path(TAB,"table_1.tex"))

## Timing comparison.
t2<-c("\\begin{table}[htbp]","\\centering",
"\\caption{Primary operational and secondary calendar treatment clocks}","\\label{tab:timing}",
"\\begin{threeparttable}\\footnotesize","\\setlength{\\tabcolsep}{4pt}","\\begin{tabular}{lcccc}","\\toprule",
"Treatment clock & Effect & Cycle-clustered SE & Block SE & 95\\% block interval \\\\","\\midrule",
sprintf("Operational 08:00--08:00 (primary) & $%s$ & (%s) & (%s) & $[%s,\\,%s]$ \\\\",f(op$tau),f(op$se_cycle9),f(op$boot_se_63),f(op$ci_lo_63),f(op$ci_hi_63)),
sprintf("Calendar 00:00--23:59 (secondary) & $%s$ & (%s) & (%s) & $[%s,\\,%s]$ \\\\",f(ca$tau),f(ca$se_cycle9),f(ca$boot_se_63),f(ca$ci_lo_63),f(ca$ci_hi_63)),
"\\bottomrule","\\end{tabular}","\\begin{tablenotes}[flushleft]\\small",
"\\item \\textit{Notes:} Both specifications use the same fixed geography, bandwidths, cell effects and boundary-by-date effects. Reports before 08:00 are assigned to the suspension beginning the previous morning in the operational specification. Intervals use 1,000 moving-block draws with block length 63 analysis dates.",
"\\end{tablenotes}","\\end{threeparttable}","\\end{table}")
writeLines(t2,file.path(TAB,"table_2.tex"))

## Placebo table: primary specification (operational clock).
pr<-xpre|>arrange(shift_m)|>transmute(row=sprintf("%+d m & $%s$ & (%s) & %s \\\\",shift_m,f(tau),f(se),f(p,3)))
t3<-c("\\begin{table}[htbp]","\\centering",
"\\caption{Placebo checks on the primary operational specification}","\\label{tab:placebo}","\\begin{threeparttable}\\small",
"\\begin{tabular}{lccc}","\\toprule","& Effect & Std. err. & $p$ \\\\","\\midrule",
"\\multicolumn{4}{l}{\\textit{Panel A: Shift-label permutations of the preferred estimator (Estimator B)}} \\\\",
sprintf("Observed estimate & $%s$ & (%s) & \\\\",f(gx("tau_observed")),f(op$se_cycle9)),
sprintf("\\multicolumn{4}{l}{%d permutations: observed percentile %s; permutation SD %s} \\\\",
  as.integer(gx("n_permutations")),f(gx("percentile"),1),f(gx("permutation_sd"))),
sprintf("\\multicolumn{4}{l}{Share of permutations at least as extreme: %s} \\\\",f(gx("share_at_least_as_extreme"),3)),
"\\midrule",
"\\multicolumn{4}{l}{\\textit{Panel B: Displaced cutoffs, boundary-specific discontinuities (Estimator A)}} \\\\",
pr$row,
sprintf("\\multicolumn{4}{l}{Dense sweep: %d cutoffs; placebo SD %s; nominal 5\\%% rejections %s\\%%} \\\\",
  as.integer(gx("dense_n")),f(gx("dense_sd")),f(100*gx("dense_nominal_rejection_rate"),1)),
sprintf("\\multicolumn{4}{l}{Share of placebo cutoffs at least as extreme: %s} \\\\",f(gx("dense_share_more_extreme"),3)),
"\\bottomrule","\\end{tabular}","\\begin{tablenotes}[flushleft]\\small",
"\\item \\textit{Notes:} Both panels use the operational 08:00--08:00 clock. Panel A relabels the nine shifts across polygons, recomputes which boundaries are active and which side is scheduled, and re-estimates the preferred specification (cell and boundary-by-date fixed effects, boundary-specific bandwidths); the observed standard error is cycle-clustered. Panel B places one-sided placebo cutoffs inside one side of each boundary and pools them with exposure-area weights; standard errors cluster by date and ignore cross-boundary covariance. The shift allocation was administrative, not random, so neither panel is an exact randomization test.",
"\\end{tablenotes}","\\end{threeparttable}","\\end{table}")
writeLines(t3,file.path(TAB,"table_4.tex"))

## Robustness summary (primary specification unless stated).
w1<-xw[xw$weights=="rademacher",]; b5<-xwin[xwin$specification=="Common 500 m window",]; b2k<-xwin[xwin$specification=="Full 2,000 m window",]
c02<-cuv("event time -2..+2","sum k=0..2"); am1<-cuv("pooled indicator","average day in [-1,+1]")
rw<-function(lab,est,se,lo,hi,typ,d=4)sprintf("%s & $%s$ & (%s) & $[%s,\\,%s]$ & %s \\\\",lab,f(est,d),f(se,d),f(lo,d),f(hi,d),typ)
t4<-c("\\begin{table}[htbp]","\\centering",
"\\caption{Operational-clock robustness checks}","\\label{tab:idchecks}","\\begin{threeparttable}\\small",
"\\setlength{\\tabcolsep}{3pt}","\\begin{tabular}{lcccc}","\\toprule","Specification & Effect & Std. err. & 95\\% interval & Interval \\\\","\\midrule",
"\\multicolumn{5}{l}{\\textit{Panel A: Inference for the preferred estimate}} \\\\",
rw("Primary model",op$tau,op$se_cycle9,op$tau-1.96*op$se_cycle9,op$tau+1.96*op$se_cycle9,"Analytic"),
rw("\\quad Moving block, 63 dates",op$tau,op$boot_se_63,op$ci_lo_63,op$ci_hi_63,"Block"),
rw("\\quad Wild cluster bootstrap-t, 34 cycles",w1$tau,w1$se_cycle9,w1$ci_lo,w1$ci_hi,"Wild"),
"\\midrule","\\multicolumn{5}{l}{\\textit{Panel B: Preferred estimator, alternative samples}} \\\\",
rw("Common 500 m window",b5$tau,b5$boot_se,b5$ci_lo,b5$ci_hi,"Block"),
rw("Full 2,000 m window",b2k$tau,b2k$boot_se,b2k$ci_lo,b2k$ci_hi,"Block"),
rw("Excluding water days touching silent dates",xsil$tau,xsil$boot_se,xsil$ci_lo,xsil$ci_hi,"Block"),
"\\midrule","\\multicolumn{5}{l}{\\textit{Panel C: Timing}} \\\\",
rw("Cumulative effect, days 0 to $+2$",c02$estimate,c02$se_cycle9,c02$ci_lo,c02$ci_hi,"Analytic"),
rw("Average day in $[-1,+1]$",am1$estimate,am1$se_cycle9,am1$ci_lo,am1$ci_hi,"Analytic"),
"\\midrule","\\multicolumn{5}{l}{\\textit{Panel D: Other estimators}} \\\\",
rw("Common 500 m, exposure-area aggregate",co$estimate,co$se_date,co$ci_lo,co$ci_hi,"Analytic"),
rw("500 m along-boundary segments",sg$estimate[1],sg$se_cycle9[1],sg$ci_lo[1],sg$ci_hi[1],"Analytic",6),
rw("1,000 m along-boundary segments",sg$estimate[2],sg$se_cycle9[2],sg$ci_lo[2],sg$ci_hi[2],"Analytic",6),
rw("PPML coefficient",pm$estimate,pm$se_cycle9,pm$ci_lo,pm$ci_hi,"Analytic"),
"\\bottomrule","\\end{tabular}","\\begin{tablenotes}[flushleft]\\small",
sprintf("\\item \\textit{Notes:} Analytic intervals cluster by nine consecutive rationing assignments, except the exposure-area aggregate, which clusters by date. Block intervals use 1,000 moving-block draws of 63 analysis dates. The wild cluster restricted bootstrap uses %s Rademacher draws over the 34 rotation cycles and inverts the test; its $p$-value for a zero effect is %s. Panel C sums the event-time coefficients of Appendix Table~\\ref{tab:dynamic} or pools a window indicator. Segment estimates use finer cells and are comparable in sign and inference, not raw magnitude. PPML includes cell and boundary-by-date effects, uses no population offset, and implies a $%s$\\%% change.",
  cm(w1$draws),f(w1$p_value_tau0,2),f(pm$percent_effect,1)),
"\\end{tablenotes}","\\end{threeparttable}","\\end{table}")
writeLines(t4,file.path(TAB,"table_3.tex"))

## Appendix dynamic table: event time -2..+2 and -3..+3 models.
cell<-function(est,se)sprintf("$%s$ (%s)",f(est),f(se))
e2<-ev|>select(event_time,e2=estimate,s2=se_cycle9); e3<-xev|>select(event_time,e3=estimate,s3=se_cycle9)
de<-full_join(e3,e2,by="event_time")|>arrange(event_time)
er<-de|>transmute(row=sprintf("$%+d$ & %s & %s \\\\",event_time,ifelse(is.na(e2),"",cell(e2,s2)),cell(e3,s3)))
c02_3<-cuv("event time -3..+3","sum k=0..2"); c03_3<-cuv("event time -3..+3","sum k=0..3")
cm1_2<-cuv("event time -2..+2","sum k=-1..+1"); cm1_3<-cuv("event time -3..+3","sum k=-1..+1")
lt<-xdt[grepl("leads",xdt$test),]; gt<-xdt[grepl("lags",xdt$test),]
tb1<-c("\\begin{table}[htbp]","\\centering",
"\\caption{Dynamic effects around an operational rationing day}","\\label{tab:dynamic}",
"\\begin{threeparttable}\\small","\\begin{tabular}{lcc}","\\toprule","Event time & Window $[-2,+2]$ & Window $[-3,+3]$ \\\\","\\midrule",er$row,"\\midrule",
sprintf("Sum, days 0 to $+2$ & %s & %s \\\\",cell(c02$estimate,c02$se_cycle9),cell(c02_3$estimate,c02_3$se_cycle9)),
sprintf("Sum, days $-1$ to $+1$ & %s & %s \\\\",cell(cm1_2$estimate,cm1_2$se_cycle9),cell(cm1_3$estimate,cm1_3$se_cycle9)),
sprintf("Sum, days 0 to $+3$ & & %s \\\\",cell(c03_3$estimate,c03_3$se_cycle9)),
sprintf("Joint test of leads & $\\chi^2(%d)=%s$, $p=%s$ & $\\chi^2(%d)=%s$, $p=%s$ \\\\",dt$df,f(dt$statistic,2),f(dt$p_value,3),lt$df,f(lt$statistic,2),f(lt$p_value,3)),
sprintf("Joint test of lags & & $\\chi^2(%d)=%s$, $p=%s$ \\\\",gt$df,f(gt$statistic,2),f(gt$p_value,3)),
"\\bottomrule","\\end{tabular}","\\begin{tablenotes}[flushleft]\\small",
"\\item \\textit{Notes:} Cycle-clustered standard errors in parentheses. Event time is measured in calendar days relative to each polygon's nearest scheduled operational water day. The omitted category is dates outside the window; it is thinner in the wider window because a nine-shift rotation leaves only event times $\\pm4$ outside $[-3,+3]$ during daily rationing. Models include cell and boundary-by-date effects and use all observed operational dates.",
"\\end{tablenotes}","\\end{threeparttable}","\\end{table}")
writeLines(tb1,file.path(TAB,"table_C1.tex"))

## Appendix heterogeneity table.
hr<-xhe|>transmute(row=sprintf("%s & %s & $%s$ & (%s) & %s & %s \\\\",ifelse(group=="Difference","",dimension),group,f(estimate),f(se_cycle9),
  ifelse(is.na(pct_of_control),"",f(pct_of_control,1)),f(p_value,3)))
hr$row<-ifelse(xhe$group=="Difference",paste0(hr$row,"[2pt]"),hr$row)
tb2<-c("\\begin{table}[htbp]","\\centering",
"\\caption{Heterogeneity by rationing frequency, programme half and day of week}","\\label{tab:heterogeneity}",
"\\begin{threeparttable}\\small","\\begin{tabular}{llcccc}","\\toprule","Dimension & Group & Effect & Std. err. & \\% of mean & $p$ \\\\","\\midrule",hr$row,"\\bottomrule","\\end{tabular}",
"\\begin{tablenotes}[flushleft]\\small","\\item \\textit{Notes:} Preferred specification with the scheduled indicator interacted with a date-level group indicator; the group main effect is absorbed by boundary-by-date fixed effects. Standard errors cluster by rotation cycle. The alternate-day phase runs from 1 July to 28 September 2024; programme halves split the 34 rotation cycles; weekend water days begin on a Saturday or Sunday. Percentages are relative to the group's comparison-side mean.",
"\\end{tablenotes}","\\end{threeparttable}","\\end{table}")
writeLines(tb2,file.path(TAB,"table_C2.tex"))

## Appendix inference table: block-length sensitivity and wild bootstrap.
blr<-xbl|>transmute(row=sprintf("Moving block, %d dates & (%s) & $[%s,\\,%s]$ & $[%s,\\,%s]$ \\\\",block_length,f(boot_se),f(ci_lo),f(ci_hi),f(ci_pct_lo,1),f(ci_pct_hi,1)))
wlr<-xw|>transmute(row=sprintf("Wild cluster bootstrap-t, %s weights & & $[%s,\\,%s]$ & $[%s,\\,%s]$ \\\\",tools::toTitleCase(weights),f(ci_lo),f(ci_hi),f(ci_pct_lo,1),f(ci_pct_hi,1)))
tb3<-c("\\begin{table}[htbp]","\\centering",
"\\caption{Sensitivity of the preferred interval to the inference procedure}","\\label{tab:inference}",
"\\begin{threeparttable}\\small","\\begin{tabular}{lccc}","\\toprule","Procedure & Std. err. & 95\\% interval & \\% of mean \\\\","\\midrule",blr$row,"\\midrule",wlr$row,"\\bottomrule","\\end{tabular}",
"\\begin{tablenotes}[flushleft]\\small",sprintf("\\item \\textit{Notes:} Preferred estimate $%s$. Moving-block rows use 1,000 draws and the seed of the primary procedure; the 63-date row is the primary interval. With 304 analysis dates, blocks of 90 or 126 dates leave too few distinct blocks for a reliable percentile interval. Wild cluster restricted bootstrap rows use %s draws over the 34 rotation cycles and invert the bootstrap-$t$ test on a grid of step 0.00005.",f(op$tau),cm(xw$draws[1])),
"\\end{tablenotes}","\\end{threeparttable}","\\end{table}")
writeLines(tb3,file.path(TAB,"table_C3.tex"))

## Boundary summary, operational panel.
pa<-read_csv(file.path(DER,"panel_operational_0800.csv.gz"),show_col_types=FALSE)
st<-pa|>group_by(boundary_id)|>summarise(dates=n_distinct(analysis_date[active==1]),reports=sum(n),cells=n_distinct(cell_id),.groups="drop")|>
  left_join(eb|>select(boundary_id,bandwidth,area_km2),by="boundary_id")|>left_join(xiw|>select(boundary_id,weight),by="boundary_id")
sr<-st|>transmute(row=sprintf("%s & %d & %s & %d & %s & %s & %s \\\\",gsub("_","--",boundary_id),dates,cm(reports),cells,f(area_km2,1),cm(bandwidth),f(100*weight,1)))
tc<-c("\\begin{table}[htbp]","\\centering","\\caption{Boundary-level operational-panel summary}","\\label{tab:summary_stats}",
"\\begin{threeparttable}\\small","\\begin{tabular}{lcccccc}","\\toprule","Boundary & Active dates & Placements & Cells & Exposure km$^2$ & Bandwidth m & B weight \\% \\\\","\\midrule",sr$row,"\\bottomrule","\\end{tabular}",
"\\begin{tablenotes}[flushleft]\\small",sprintf("\\item \\textit{Notes:} Counts use the primary 08:00--08:00 clock and all %s report--boundary placements on its %d usable dates; the calendar clock has %s placements on 299 usable dates. A report close to a junction may enter more than one fixed boundary panel. B weight is the boundary's share of the identifying variation in the preferred estimator, which equals its share of within-bandwidth cell-dates.",cm(sum(st$reports)),op$n_dates,cm(sum(read_csv(file.path(DER,"panel_calendar_secondary.csv.gz"),show_col_types=FALSE)$n))),"\\end{tablenotes}","\\end{threeparttable}","\\end{table}")
writeLines(tc,file.path(TAB,"table_C4.tex"))

## Rotation balance: calendar composition of each side's scheduled dates.
rb<-xrb|>transmute(row=sprintf("%s & %d / %d & %s / %s & %s / %s & %s & %s \\\\",gsub("_","--",boundary_id),dates_a,dates_b,
  f(weekend_share_a,2),f(weekend_share_b,2),f(alt_phase_share_a,2),f(alt_phase_share_b,2),f(mean_date_gap_days,1),f(weekday_chisq_p,2)))
tc2<-c("\\begin{table}[htbp]","\\centering","\\caption{Rotation balance: when each side of a boundary is scheduled}","\\label{tab:rotation_balance}",
"\\begin{threeparttable}\\footnotesize","\\setlength{\\tabcolsep}{4pt}","\\begin{tabular}{lccccc}","\\toprule","& Scheduled & Weekend & Alternate-day & Mean date & Weekday \\\\","Boundary & dates, a / b & share, a / b & share, a / b & gap (days) & $p$ \\\\","\\midrule",rb$row,"\\bottomrule","\\end{tabular}",
"\\begin{tablenotes}[flushleft]\\small","\\item \\textit{Notes:} Operational dates on which each endpoint polygon of a boundary is scheduled. The weekday $p$-value is from a $\\chi^2$ test of equal day-of-week distributions across the two sides. Mean date gap is the difference in the average scheduled date of side a and side b.","\\end{tablenotes}","\\end{threeparttable}","\\end{table}")
writeLines(tc2,file.path(TAB,"table_C5.tex"))

## Figures.
th<-theme_minimal(base_size=11)+theme(panel.grid.minor=element_blank())
mo<-read_csv(file.path(DER,"monthly_maltrato_citywide.csv"),show_col_types=FALSE) |>
  mutate(month=as.Date(paste0(month,"-01")))
stopifnot(nrow(mo)==28L, !anyNA(mo$month), !anyNA(mo$maltrato_calls))
p2<-ggplot(mo,aes(month,maltrato_calls))+
  geom_vline(xintercept=as.Date(c("2024-04-11","2025-04-12")),
             linetype="dashed",colour=PURPLE,linewidth=.5)+
  geom_line(colour=PURPLE,linewidth=1)+geom_point(colour=PURPLE,size=2)+
  scale_x_date(breaks=seq(as.Date("2023-02-01"),as.Date("2025-05-01"),
                          by="3 months"),date_labels="%b\n%Y",
               limits=as.Date(c("2023-01-01","2025-05-31")))+
  labs(title="Monthly domestic-violence emergency calls, Bogotá",
       x=NULL,y="Calls per month")+th
ggsave(file.path(FIG,"Figure_2.pdf"),p2,width=8,height=4.5,device=cairo_pdf)
fp<-eb|>mutate(label=factor(gsub("_","--",boundary_id),levels=gsub("_","--",boundary_id[order(tau)])),lo=tau-1.96*se,hi=tau+1.96*se)
p3<-ggplot(fp,aes(tau,label))+geom_vline(xintercept=0,linetype="dashed",colour=GREY)+geom_vline(xintercept=op$A_tau,colour=PURPLE)+geom_errorbarh(aes(xmin=lo,xmax=hi),height=0,colour=PURPLE)+geom_point(aes(size=area_km2),shape=21,fill="white",colour=PURPLE)+labs(x="Effect (reports per cell-day)",y="Boundary",size="Exposure km2")+th
ggsave(file.path(FIG,"Figure_3.pdf"),p3,width=7,height=5.2,device=cairo_pdf)
p4<-ggplot(dp,aes(band_m,estimate))+geom_hline(yintercept=0,linetype="dashed",colour=GREY)+geom_ribbon(aes(ymin=ci_lo,ymax=ci_hi),fill=LILAC,alpha=.25)+geom_line(colour=PURPLE)+geom_point(colour=PURPLE)+labs(x="Distance-band midpoint (m)",y="Operational ITT")+th
ggsave(file.path(FIG,"Figure_4.pdf"),p4,width=6.4,height=4.2,device=cairo_pdf)
p5<-ggplot(xden,aes(tau))+geom_histogram(bins=26,fill=LILAC)+geom_vline(xintercept=gx("displaced_true_tau"),colour=PURPLE,linewidth=1)+labs(x="Effect at displaced cutoff",y="Placebo cutoffs")+th
ggsave(file.path(FIG,"Figure_6.pdf"),p5,width=6.4,height=4,device=cairo_pdf)
pv<-xpb|>filter(draw>0);obs<-xpb$tau[xpb$draw==0]
p6<-ggplot(pv,aes(tau))+geom_histogram(bins=40,fill=LILAC)+geom_vline(xintercept=obs,colour=PURPLE,linewidth=1)+labs(x="Effect under shift-label placebo",y="Permutations")+th
ggsave(file.path(FIG,"Figure_7.pdf"),p6,width=6.4,height=4,device=cairo_pdf)
tm<-tibble(clock=c("Operational (primary)","Calendar (secondary)"),estimate=c(op$tau,ca$tau),lo=c(op$ci_lo_63,ca$ci_lo_63),hi=c(op$ci_hi_63,ca$ci_hi_63))
p7<-ggplot(tm,aes(estimate,clock))+geom_vline(xintercept=0,linetype="dashed",colour=GREY)+geom_errorbarh(aes(xmin=lo,xmax=hi),height=0,colour=PURPLE)+geom_point(colour=PURPLE,size=2.5)+labs(x="ITT (63-analysis-date block 95% interval)",y=NULL)+th
ggsave(file.path(FIG,"Figure_5.pdf"),p7,width=6.4,height=3.4,device=cairo_pdf)
p8<-ggplot(xev,aes(event_time,estimate))+geom_hline(yintercept=0,linetype="dashed",colour=GREY)+geom_errorbar(aes(ymin=ci_lo,ymax=ci_hi),width=.12,colour=PURPLE)+geom_point(colour=PURPLE,size=2.5)+scale_x_continuous(breaks=-3:3)+labs(x="Event time (days)",y="Operational ITT")+th
ggsave(file.path(FIG,"Figure_C1.pdf"),p8,width=6.4,height=4,device=cairo_pdf)

message("[07] wrote Tables 1--4 and C1--C5 and Figures 2--7 and C1")
