#!/usr/bin/env Rscript
## =============================================================================
## 04_placebo_checks.R
##
## Falsification tests on the fixed-geography panel.
##
##  (1) SPATIAL PLACEBOS for estimator A. Artificial cutoffs displaced from the
##      true boundary, computed ONE-SIDED: each uses only observations on the side
##      of the true cutoff on which the artificial cutoff falls, with window
##      half-width min(|d|, MAX_D - |d|), so that no placebo window straddles the
##      real discontinuity. Reported at the pre-specified +/-250, +/-500, +/-750 m
##      and over a dense sweep at 50 m steps, with the true estimate placed in the
##      resulting distribution rather than judged against nominal levels.
##
##  (2) SHIFT-LABEL PLACEBOS for an ancillary all-date cell-and-date FE model.
##      This is deliberately not the primary boundary-by-date estimator B and
##      its distribution must not be used as inference for that estimator.
##      Because cell contents are fixed by geography and do not depend on which
##      boundaries are active, the nine shift labels can be
##      permuted across polygons to generate alternative citywide assignments that
##      are internally feasible -- every polygon has exactly one shift, every date
##      rations exactly one shift -- while leaving the outcome untouched.
##
##      This is a PLACEBO, not inference, and is labelled as such throughout. The
##      real allocation of polygons to shifts was an administrative decision about
##      hydraulic topology, not a randomisation, so the permutation distribution
##      describes how the estimator behaves under alternative labellings; it does
##      not licence an exact p-value; no such claim is made.
## =============================================================================

suppressPackageStartupMessages({library(dplyr); library(readr); library(tidyr)})
ROOT <- Sys.getenv("ROOT", "."); DER <- file.path(ROOT,"data","derived")
PUB  <- file.path(ROOT,"data","public"); OUT <- file.path(ROOT,"output")
BIN_W <- 50; MAX_D <- 2000; SEED <- 20240411L; N_PERM <- 999L
set.seed(SEED)

## panel may be shipped compressed; resolve either name
.panel_path <- function(DER) {
  for (f in c("panel_fixed_geography.csv", "panel_fixed_geography.csv.gz"))
    if (file.exists(file.path(DER, f))) return(file.path(DER, f))
  stop("panel_fixed_geography.csv[.gz] not found in ", DER)
}
panel <- read_csv(.panel_path(DER), show_col_types=FALSE) |>
  mutate(date = as.Date(date))
bws <- read_csv(file.path(DER,"bandwidths_mserd.csv"), show_col_types=FALSE)
cal <- read_csv(file.path(PUB,"rationing_calendar.csv"), show_col_types=FALSE) |>
  transmute(date = as.Date(date), shift = as.integer(turno_group_id))
if (any(!panel$date %in% cal$date))
  stop("Fixed-geography panel contains a date outside the official rationing calendar.")
expected_boundaries <- read_csv(file.path(DER,"adjacency_pairs.csv"),show_col_types=FALSE)$boundary_id
if (!setequal(unique(panel$boundary_id),expected_boundaries))
  stop("Fixed-geography panel omits validated boundaries; rebuild with --full.")
xw  <- read_csv(file.path(PUB,"polygon_shift_crosswalk.csv"), show_col_types=FALSE)
bnds <- sort(unique(panel$boundary_id))
Hb <- setNames(bws$h_mserd[match(bnds, bws$boundary_id)], bnds)
Hb[is.na(Hb)] <- median(bws$h_mserd)
act <- panel |> filter(active == 1)

## -----------------------------------------------------------------------------
## machinery
## -----------------------------------------------------------------------------
cluster_vcov <- function(X, u, w, cl) {
  bread <- solve(crossprod(X*sqrt(w))); meat <- matrix(0, ncol(X), ncol(X))
  for (g in split(seq_along(u), cl)) {
    s <- crossprod(X[g,,drop=FALSE], w[g]*u[g]); meat <- meat + tcrossprod(s) }
  G <- length(unique(cl)); N <- length(u); K <- ncol(X)
  bread %*% meat %*% bread * (G/(G-1)) * ((N-1)/(N-K))
}
## local linear discontinuity in y at xtilde = 0, triangular kernel, bandwidth h
ll_disc <- function(y, xt, h, cl) {
  k <- abs(xt) < h; if (sum(k) < 20) return(NULL)
  y <- y[k]; xt <- xt[k]; cl <- cl[k]
  w <- 1 - abs(xt)/h; D <- as.numeric(xt < 0)
  if (all(D == 1) || all(D == 0)) return(NULL)
  X <- cbind(1, D, xt, xt*D)
  b <- tryCatch(solve(crossprod(X*sqrt(w)), crossprod(X, w*y)), error=function(e) NULL)
  if (is.null(b)) return(NULL)
  u <- as.numeric(y - X %*% b); V <- cluster_vcov(X, u, w, cl)
  c(tau = b[2], se = sqrt(V[2,2]), n = sum(k))
}

## area weights (pre-outcome)
area_w <- panel |> distinct(boundary_id, cell_id, mag, area_m2) |>
  filter(mag < as.numeric(Hb[boundary_id])) |>
  group_by(boundary_id) |> summarise(area = sum(area_m2), .groups = "drop")
AW <- setNames(area_w$area, area_w$boundary_id)

pool_area <- function(e) {
  w <- AW[e$boundary_id]
  c(tau = sum(w*e$tau)/sum(w),
    se  = sqrt(sum(w^2*e$se^2))/sum(w))
}

## -----------------------------------------------------------------------------
## (1) spatial placebos, one-sided
## -----------------------------------------------------------------------------
## d > 0 places the artificial cutoff on the CONTROL side, d < 0 on the RATIONED
## side. Only observations on that side are used, so the true cutoff at 0 is never
## inside the placebo window.
placebo_at <- function(d) {
  half <- min(abs(d), MAX_D - abs(d))
  if (half < 100) return(NULL)
  e <- bind_rows(lapply(bnds, function(b) {
    s <- act[act$boundary_id == b, ]
    s <- if (d > 0) s[s$rationed == 0L, ] else s[s$rationed == 1L, ]
    if (!nrow(s)) return(NULL)
    x <- if (d > 0) s$mag else -s$mag          # signed position on that side
    r <- ll_disc(s$n, x - d, min(half, Hb[[b]]), s$date)
    if (is.null(r)) return(NULL)
    tibble::tibble(boundary_id = b, tau = r[["tau"]], se = r[["se"]], n = r[["n"]])
  }))
  if (!nrow(e)) return(NULL)
  p <- pool_area(e)
  tibble::tibble(shift_m = d, tau = p[["tau"]], se = p[["se"]],
                 z = p[["tau"]]/p[["se"]], n_boundaries = nrow(e), half_width = half)
}

## the true cutoff, estimated the same way for comparability (two-sided window)
true_e <- bind_rows(lapply(bnds, function(b) {
  s <- act[act$boundary_id == b, ]
  x <- ifelse(s$rationed == 1L, -s$mag, s$mag)
  r <- ll_disc(s$n, x, Hb[[b]], s$date); if (is.null(r)) return(NULL)
  tibble::tibble(boundary_id = b, tau = r[["tau"]], se = r[["se"]], n = r[["n"]])
}))
TRUE_P <- pool_area(true_e)

pre <- bind_rows(lapply(c(-750,-500,-250,250,500,750), placebo_at))
dense <- bind_rows(lapply(setdiff(seq(-1750, 1750, by = 50), c(-50,0,50)), placebo_at))

## calibrate the true estimate against the dense placebo distribution
sd_plac <- sd(dense$tau, na.rm = TRUE)
p_calib <- mean(abs(dense$tau) >= abs(TRUE_P[["tau"]]), na.rm = TRUE)

## -----------------------------------------------------------------------------
## (2) shift-label permutation placebos for ancillary cell-and-date FE model
## -----------------------------------------------------------------------------
demean2 <- function(v, i1, i2, n1, n2, tol = 1e-10, maxit = 1000) {
  v <- as.numeric(v)
  for (k in seq_len(maxit)) {
    v0 <- v
    v <- v - (rowsum(v, i1)/tabulate(i1, n1))[i1]
    v <- v - (rowsum(v, i2)/tabulate(i2, n2))[i2]
    if (max(abs(v - v0)) < tol) break
  }
  as.numeric(v)
}
## all dates, so that the permutation never has to respect an activity screen
pb <- panel |> filter(mag < as.numeric(Hb[boundary_id])) |>
  left_join(cal, by = "date") |>
  mutate(own_shift = as.integer(xw$shift_id[match(polygon_id, xw$polygon_id)]))
f1 <- factor(pb$cell_id); f2 <- factor(pb$date)
i1 <- as.integer(f1); i2 <- as.integer(f2); n1 <- nlevels(f1); n2 <- nlevels(f2)
ydm <- demean2(pb$n, i1, i2, n1, n2)

tau_for <- function(map) {                       # map: shift -> permuted shift
  D <- as.numeric(map[pb$own_shift] == pb$shift)
  Dd <- demean2(D, i1, i2, n1, n2)
  den <- sum(Dd*Dd); if (den <= 0) return(NA_real_)
  sum(Dd*ydm)/den
}
identity_map <- 1:9
tau_obs <- tau_for(identity_map)
perm <- vapply(seq_len(N_PERM), function(i) tau_for(sample(9)), numeric(1))
perm <- perm[is.finite(perm)]
pos <- mean(perm <= tau_obs)
p_perm <- (1 + sum(abs(perm) >= abs(tau_obs)))/(1 + length(perm))

## -----------------------------------------------------------------------------
write_csv(pre,   file.path(OUT,"placebo_prespecified_fixed_geo.csv"))
write_csv(dense, file.path(OUT,"placebo_dense_fixed_geo.csv"))
write_csv(tibble::tibble(draw = c(0, seq_along(perm)), tau = c(tau_obs, perm)),
          file.path(OUT,"placebo_shift_permutations.csv"))
write_csv(tibble::tibble(
  quantity = c("true_tau_area_pooled","true_se","placebo_sd","placebo_n",
               "share_placebos_more_extreme","perm_tau_obs","perm_n",
               "perm_percentile","perm_share_more_extreme"),
  value = c(TRUE_P[["tau"]], TRUE_P[["se"]], sd_plac, nrow(dense), p_calib,
            tau_obs, length(perm), 100*pos, p_perm)),
  file.path(OUT,"placebo_summary_fixed_geo.csv"))

cat("\n================ FALSIFICATION TESTS ================\n")
cat(sprintf("true cutoff, area-pooled : tau %+.5f (SE %.5f)\n\n",
            TRUE_P[["tau"]], TRUE_P[["se"]]))
cat("--- pre-specified one-sided placebo cutoffs ---\n")
print(as.data.frame(pre |> transmute(shift_m, tau = round(tau,4), se = round(se,4),
      z = round(z,2), p = round(2*pnorm(-abs(z)),3), half_width)), row.names = FALSE)
cat(sprintf("\nrejections at 5%%: %d of %d\n", sum(2*pnorm(-abs(pre$z)) < 0.05), nrow(pre)))
cat("\n--- dense sweep, 50 m steps ---\n")
cat(sprintf("placebo estimates: %d, SD %.5f, range [%+.4f, %+.4f]\n",
            nrow(dense), sd_plac, min(dense$tau), max(dense$tau)))
cat(sprintf("share of placebos at least as extreme as the true estimate: %.3f\n", p_calib))
cat(sprintf("nominal 5%% rejections among placebos: %d of %d (%.1f%%; descriptive only)\n",
            sum(2*pnorm(-abs(dense$z)) < 0.05), nrow(dense),
            100*mean(2*pnorm(-abs(dense$z)) < 0.05)))
cat("Overlapping windows are dependent; this is not a test of nominal size.\n")
cat("\n--- shift-label permutation placebo, ancillary all-date model ---\n")
cat(sprintf("observed tau %+.5f sits at percentile %.1f of %d permutations\n",
            tau_obs, 100*pos, length(perm)))
cat(sprintf("share of permutations at least as extreme: %.3f\n", p_perm))
cat(sprintf("permutation SD %.5f (placebo dispersion, not an analytic standard error)\n", sd(perm)))
cat("NOTE: a placebo, not inference. The shift allocation was administrative,\n")
cat("      not random, so this describes estimator behaviour under alternative\n")
cat("      labellings and does not licence an exact p-value.\n")
cat("=====================================================================\n")
