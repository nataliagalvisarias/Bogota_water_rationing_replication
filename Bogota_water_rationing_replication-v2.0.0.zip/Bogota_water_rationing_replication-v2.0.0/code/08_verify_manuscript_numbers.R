#!/usr/bin/env Rscript
## Machine-readable audit that each CSV value appears in the manuscript with
## the declared display precision.  This checks literal bytes, not numeric
## equivalence after LaTeX rendering.
suppressPackageStartupMessages({library(readr);library(dplyr);library(tibble)})
ROOT<-Sys.getenv("ROOT",".");OUT<-file.path(ROOT,"output")
MAIN_TEX<-Sys.getenv("MAIN_TEX",file.path(ROOT,"manuscript","manuscript.tex"))
main<-paste(readLines(MAIN_TEX,warn=FALSE),collapse="\n")
tim<-read_csv(file.path(OUT,"primary_timing.csv"),show_col_types=FALSE)
ev<-read_csv(file.path(OUT,"dynamic_event_time.csv"),show_col_types=FALSE)
cu<-read_csv(file.path(OUT,"dynamic_cumulative.csv"),show_col_types=FALSE)
co<-read_csv(file.path(OUT,"common500_pooled.csv"),show_col_types=FALSE)
sg<-read_csv(file.path(OUT,"along_boundary_segments.csv"),show_col_types=FALSE)
pm<-read_csv(file.path(OUT,"ppml.csv"),show_col_types=FALSE)
fmt<-function(x,d=4)formatC(x,format="f",digits=d)
lit<-function(label,file,column,row,value,digits=4,prefix="")
  tibble(label,file,column,row,raw_value=value,
         display=if(nzchar(prefix))paste0(prefix,fmt(abs(value),digits)) else fmt(value,digits))
audit<-bind_rows(
  lit("operational point", "primary_timing.csv","tau",1,tim$tau[1]),
  lit("operational block lower", "primary_timing.csv","ci_lo_63",1,tim$ci_lo_63[1]),
  lit("operational block upper", "primary_timing.csv","ci_hi_63",1,tim$ci_hi_63[1],prefix="+"),
  lit("operational percent lower", "primary_timing.csv","ci_pct_lo",1,tim$ci_pct_lo[1],1),
  lit("operational percent upper", "primary_timing.csv","ci_pct_hi",1,tim$ci_pct_hi[1],1,prefix="+"),
  lit("calendar point", "primary_timing.csv","tau",2,tim$tau[2]),
  lit("calendar block lower", "primary_timing.csv","ci_lo_63",2,tim$ci_lo_63[2]),
  lit("calendar block upper", "primary_timing.csv","ci_hi_63",2,tim$ci_hi_63[2],prefix="+"),
  lit("operational area aggregate", "primary_timing.csv","A_tau",1,tim$A_tau[1],prefix="+"),
  lit("operational area SE", "primary_timing.csv","A_se",1,tim$A_se[1]),
  lit("event day zero", "dynamic_event_time.csv","estimate",3,ev$estimate[ev$event_time==0]),
  lit("event day zero SE", "dynamic_event_time.csv","se_cycle9",3,ev$se_cycle9[ev$event_time==0]),
  lit("cumulative point", "dynamic_cumulative.csv","estimate",1,cu$estimate),
  lit("cumulative SE", "dynamic_cumulative.csv","se_cycle9",1,cu$se_cycle9),
  lit("common 500 point", "common500_pooled.csv","estimate",1,co$estimate,prefix="+"),
  lit("common 500 SE", "common500_pooled.csv","se_date",1,co$se_date),
  lit("segment 500 point", "along_boundary_segments.csv","estimate",1,sg$estimate[1],6),
  lit("segment 500 SE", "along_boundary_segments.csv","se_cycle9",1,sg$se_cycle9[1],6),
  lit("segment 1000 point", "along_boundary_segments.csv","estimate",2,sg$estimate[2],6),
  lit("segment 1000 SE", "along_boundary_segments.csv","se_cycle9",2,sg$se_cycle9[2],6),
  lit("PPML point", "ppml.csv","estimate",1,pm$estimate),
  lit("PPML SE", "ppml.csv","se_cycle9",1,pm$se_cycle9)
)
## Additional analyses: checked only when 10_additional_analyses.R outputs exist.
if (file.exists(file.path(OUT,"ext_dynamic_cumulative.csv"))) {
  xc<-read_csv(file.path(OUT,"ext_dynamic_cumulative.csv"),show_col_types=FALSE)
  xw<-read_csv(file.path(OUT,"ext_wild_cluster_bootstrap.csv"),show_col_types=FALSE)
  xwin<-read_csv(file.path(OUT,"ext_estimatorB_windows.csv"),show_col_types=FALSE)
  xs<-read_csv(file.path(OUT,"ext_silent_days_excluded.csv"),show_col_types=FALSE)
  xh<-read_csv(file.path(OUT,"ext_heterogeneity.csv"),show_col_types=FALSE)
  xp<-read_csv(file.path(OUT,"ext_placebo_summary_operational.csv"),show_col_types=FALSE)
  xt<-read_csv(file.path(OUT,"ext_dynamic_tests_pm3.csv"),show_col_types=FALSE)
  xa<-read_csv(file.path(OUT,"ext_active_boundary_counts.csv"),show_col_types=FALSE)
  c02<-xc[xc$window_model=="event time -2..+2"&xc$combination=="sum k=0..2",]
  avg<-xc[xc$window_model=="pooled indicator"&xc$combination=="average day in [0,+2]",]
  rad<-xw[xw$weights=="rademacher",]; web<-xw[xw$weights=="webb",]
  w5<-xwin[xwin$specification=="Common 500 m window",]; w2<-xwin[xwin$specification=="Full 2,000 m window",]
  pv<-function(k)xp$value[xp$quantity==k]
  audit<-bind_rows(audit,
    lit("cumulative 0..2 point","ext_dynamic_cumulative.csv","estimate",1,c02$estimate),
    lit("cumulative 0..2 SE","ext_dynamic_cumulative.csv","se_cycle9",1,c02$se_cycle9),
    lit("cumulative 0..2 lower","ext_dynamic_cumulative.csv","ci_lo",1,c02$ci_lo),
    lit("cumulative 0..2 upper","ext_dynamic_cumulative.csv","ci_hi",1,c02$ci_hi,prefix="+"),
    lit("cumulative 0..2 percent","ext_dynamic_cumulative.csv","pct_of_control",1,c02$pct_of_control,1),
    lit("cumulative 0..2 upper percent","ext_dynamic_cumulative.csv","ci_hi/mean",1,100*c02$ci_hi/c02$control_mean,1,prefix="+"),
    lit("average day 0..2","ext_dynamic_cumulative.csv","estimate",6,avg$estimate),
    lit("wild Rademacher lower","ext_wild_cluster_bootstrap.csv","ci_lo",1,rad$ci_lo),
    lit("wild Rademacher upper","ext_wild_cluster_bootstrap.csv","ci_hi",1,rad$ci_hi,prefix="+"),
    lit("wild Rademacher upper pct","ext_wild_cluster_bootstrap.csv","ci_pct_hi",1,rad$ci_pct_hi,1,prefix="+"),
    lit("wild Webb upper","ext_wild_cluster_bootstrap.csv","ci_hi",2,web$ci_hi,prefix="+"),
    lit("B 500 m point","ext_estimatorB_windows.csv","tau",2,w5$tau),
    lit("B 500 m upper pct","ext_estimatorB_windows.csv","ci_pct_hi",2,w5$ci_pct_hi,1,prefix="+"),
    lit("B 2 km point","ext_estimatorB_windows.csv","tau",3,w2$tau),
    lit("B 2 km upper pct","ext_estimatorB_windows.csv","ci_pct_hi",3,w2$ci_pct_hi,1,prefix="+"),
    lit("silent days excluded point","ext_silent_days_excluded.csv","tau",1,xs$tau),
    lit("weekend percent","ext_heterogeneity.csv","pct_of_control",8,xh$pct_of_control[8],1),
    lit("frequency difference p","ext_heterogeneity.csv","p_value",3,xh$p_value[3],2),
    lit("permutation SD","ext_placebo_summary_operational.csv","value",5,pv("permutation_sd")),
    lit("dense placebo SD","ext_placebo_summary_operational.csv","value",9,pv("dense_sd")),
    lit("lead test p pm3","ext_dynamic_tests_pm3.csv","p_value",1,xt$p_value[1],3),
    lit("lag test p pm3","ext_dynamic_tests_pm3.csv","p_value",2,xt$p_value[2],3),
    lit("active boundaries, rationed","ext_active_boundary_counts.csv","mean_active_boundaries",1,xa$mean_active_boundaries[xa$group=="rationed"],2),
    lit("active boundaries, comparison","ext_active_boundary_counts.csv","mean_active_boundaries",2,xa$mean_active_boundaries[xa$group=="comparison"],2),
    lit("active boundaries, correlation","ext_active_boundary_counts.csv","mean_active_boundaries",3,xa$mean_active_boundaries[xa$group=="correlation_with_treatment"],2))
}
audit<-audit |> mutate(found_in_manuscript=vapply(display,function(x)grepl(x,main,fixed=TRUE),logical(1)))
stopifnot("found_in_manuscript" %in% names(audit))
write_csv(audit,file.path(OUT,"manuscript_number_audit.csv"))
if(!all(audit$found_in_manuscript)) {
  print(audit|>filter(!found_in_manuscript));stop(basename(MAIN_TEX)," numeric audit failed")
}
message("[08] all ",nrow(audit)," displayed values found byte-for-byte in ",basename(MAIN_TEX))
