#!/usr/bin/env Rscript
## Build the primary 08:00--08:00 panel and the secondary calendar panel.
suppressPackageStartupMessages({library(sf); library(dplyr); library(readr); library(tidyr)})
ROOT <- Sys.getenv("ROOT", "."); DER <- file.path(ROOT, "data", "derived")
PUB <- file.path(ROOT, "data", "public"); OUT <- file.path(ROOT, "output")
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)
BIN_W <- 50; MAX_D <- 2000; N_BOOT <- 1000L; BLOCK_L <- 63L; SEED <- 20240914L
set.seed(SEED)
HAS_RAW <- exists("INC_ALL_SF")

adj <- read_csv(file.path(DER, "adjacency_pairs.csv"), show_col_types = FALSE)
area <- read_csv(file.path(DER, "cell_exposure_area.csv"), show_col_types = FALSE)
bws <- read_csv(file.path(DER, "bandwidths_mserd.csv"), show_col_types = FALSE)
cal <- read_csv(file.path(PUB, "rationing_calendar.csv"), show_col_types = FALSE) |>
  transmute(date = as.Date(date), shift = as.integer(turno_group_id)) |>
  arrange(date) |> mutate(cycle_id = (row_number() - 1L) %/% 9L + 1L)
xw <- read_csv(file.path(PUB, "polygon_shift_crosswalk.csv"), show_col_types = FALSE)
p2s <- setNames(xw$shift_id, as.character(xw$polygon_id))
bnds <- sort(unique(adj$boundary_id))
Hb <- setNames(bws$h_mserd[match(bnds, bws$boundary_id)], bnds)
Hb[is.na(Hb)] <- median(bws$h_mserd)
write_csv(tibble(boundary_id=bnds,bandwidth=as.numeric(Hb[bnds]),
                 provenance=if_else(bnds %in% bws$boundary_id,
                   "pre-existing pinned bandwidth","median of 15 pinned bandwidths")),
          file.path(OUT,"bandwidth_provenance.csv"))

if (HAS_RAW) {
poly <- st_read(file.path(DER, "hydraulic_polygons_analysis.gpkg"), quiet = TRUE) |>
  st_zm(drop = TRUE) |> st_make_valid() |> filter(!is.na(polygon_id)) |> arrange(polygon_id)
g <- st_geometry(poly); pid <- poly$polygon_id
gi <- function(k) g[[which(pid == k)]]
lines <- lapply(seq_len(nrow(adj)), function(i) {
  a <- st_sfc(gi(adj$poly_a[i]), crs = 3116); b <- st_sfc(gi(adj$poly_b[i]), crs = 3116)
  st_union(st_intersection(st_boundary(a), st_boundary(b)))
})

inc <- INC_ALL_SF |> mutate(water_day = date - as.integer(hour < 8L))
plc <- bind_rows(lapply(seq_len(nrow(adj)), function(i) {
  sel <- which(inc$polygon_id %in% c(adj$poly_a[i], adj$poly_b[i]))
  if (!length(sel)) return(NULL)
  dst <- as.numeric(st_distance(inc[sel, ], lines[[i]])); keep <- which(dst < MAX_D)
  if (!length(keep)) return(NULL)
  tibble(boundary_id = adj$boundary_id[i], crime_id = inc$crime_id[sel][keep],
         date = inc$date[sel][keep], water_day = inc$water_day[sel][keep],
         hour = inc$hour[sel][keep], polygon_id = inc$polygon_id[sel][keep],
         mag = floor(dst[keep] / BIN_W) * BIN_W + BIN_W / 2)
}))
message(sprintf("[05] %s placements; %.1f%% of reports occur 00:00--07:59",
                format(nrow(plc), big.mark = ","), 100 * mean(inc$hour < 8L)))

sides <- bind_rows(adj |> transmute(boundary_id, side = "a", polygon_id = poly_a),
                   adj |> transmute(boundary_id, side = "b", polygon_id = poly_b))
skel_cell <- sides |> inner_join(area |> select(boundary_id, polygon_id, mag, area_m2),
                                  by = c("boundary_id", "polygon_id"))

build_panel <- function(dayvar) {
  cnt <- plc |> transmute(boundary_id, analysis_date = .data[[dayvar]], polygon_id, mag) |>
    filter(analysis_date %in% cal$date) |>
    count(boundary_id, analysis_date, polygon_id, mag, name = "n")
  available <- sort(cal$date[cal$date %in% unique(inc[[dayvar]])])
  sch <- cal |> filter(date %in% available) |> rename(analysis_date = date)
  skel_cell |> crossing(sch) |>
    mutate(rationed = as.integer(p2s[as.character(polygon_id)] == shift)) |>
    left_join(cnt, by = c("boundary_id", "analysis_date", "polygon_id", "mag")) |>
    left_join(adj |> select(boundary_id, shift_a, shift_b), by = "boundary_id") |>
    mutate(n = coalesce(n, 0L), active = as.integer(shift == shift_a | shift == shift_b),
           cell_id = paste(boundary_id, side, mag, sep = "|"),
           boundary_date_id = paste(boundary_id, analysis_date, sep = "|")) |>
    select(-shift_a, -shift_b) |> arrange(boundary_id, analysis_date, side, mag)
}
pan_cal <- build_panel("date"); pan_wat <- build_panel("water_day")
write_csv(pan_wat, file.path(DER, "panel_operational_0800.csv.gz"))
write_csv(pan_cal, file.path(DER, "panel_calendar_secondary.csv.gz"))
} else {
  message("[05] public path: loading shipped operational and calendar panels")
  pan_wat <- read_csv(file.path(DER, "panel_operational_0800.csv.gz"), show_col_types = FALSE) |>
    mutate(analysis_date = as.Date(analysis_date))
  pan_cal <- read_csv(file.path(DER, "panel_calendar_secondary.csv.gz"), show_col_types = FALSE) |>
    mutate(analysis_date = as.Date(analysis_date))
}
if (any(!pan_wat$analysis_date %in% cal$date) ||
    any(!pan_cal$analysis_date %in% cal$date))
  stop("Treatment-clock panel contains a date outside the official rationing calendar.")
if (!setequal(unique(pan_wat$boundary_id),adj$boundary_id) ||
    !setequal(unique(pan_cal$boundary_id),adj$boundary_id))
  stop("Count panels omit validated boundaries; rebuild with --full.")

demeanK <- function(v, idx, nlev, tol = 1e-10, maxit = 1000L) {
  v <- as.numeric(v)
  for (iter in seq_len(maxit)) {
    old <- v
    for (j in seq_along(idx)) v <- v - (rowsum(v, idx[[j]]) / tabulate(idx[[j]], nlev[j]))[idx[[j]]]
    if (max(abs(v - old)) < tol) break
  }
  v
}
fe_fit <- function(d, y = d$n, x = d$rationed) {
  fs <- list(factor(d$cell_id), factor(d$boundary_date_id)); idx <- lapply(fs, as.integer)
  nl <- vapply(fs, nlevels, integer(1)); yy <- demeanK(y, idx, nl); xx <- demeanK(x, idx, nl)
  den <- sum(xx * xx); if (!is.finite(den) || den <= 0) return(NULL)
  tau <- sum(xx * yy) / den
  list(tau = tau, x = xx, residual = yy - tau * xx, den = den,
       K = sum(nl) + 1L, n = nrow(d))
}
cluster_se <- function(fit, cl) {
  score <- vapply(split(seq_along(cl), cl), function(ii) sum(fit$x[ii] * fit$residual[ii]), numeric(1))
  G <- length(score)
  sqrt(sum(score^2) / fit$den^2 * (G / (G - 1)) * ((fit$n - 1) / (fit$n - fit$K)))
}
in_bandwidth <- function(p) p |> filter(active == 1L, mag < as.numeric(Hb[boundary_id]))
moving_block_draws <- function(d, L = BLOCK_L, B = N_BOOT) {
  dates <- sort(unique(d$analysis_date)); nd <- length(dates); by_date <- split(seq_len(nrow(d)), d$analysis_date)
  vapply(seq_len(B), function(rep) {
    starts <- sample.int(nd - L + 1L, ceiling(nd / L), replace = TRUE)
    chosen <- dates[unlist(lapply(starts, function(s) s:(s + L - 1L)))][seq_len(nd)]
    lens <- lengths(by_date[as.character(chosen)])
    s <- d[unlist(by_date[as.character(chosen)], use.names = FALSE), ]
    s$boundary_date_id <- paste(s$boundary_id, rep(seq_along(chosen), lens), sep = "|")
    z <- fe_fit(s); if (is.null(z)) NA_real_ else z$tau
  }, numeric(1))
}
panel_result <- function(p, label) {
  d <- in_bandwidth(p); fit <- fe_fit(d); boot <- moving_block_draws(d); boot <- boot[is.finite(boot)]
  ## Freeze the reporting scale below insignificant floating-summation noise
  ## between in-memory restricted builds and CSV-loaded public runs.
  base <- signif(mean(d$n[d$rationed == 0L]), 12)
  tibble(timing = label, tau = fit$tau, se_date = cluster_se(fit, d$analysis_date),
         se_cycle9 = cluster_se(fit, d$cycle_id), boot_se_63 = sd(boot),
         ci_lo_63 = unname(quantile(boot, .025)), ci_hi_63 = unname(quantile(boot, .975)),
         control_mean = base, pct = 100 * fit$tau / base,
         ci_pct_lo = 100 * quantile(boot, .025) / base,
         ci_pct_hi = 100 * quantile(boot, .975) / base,
         n_rows = nrow(d), n_dates = n_distinct(d$analysis_date), n_incidents = sum(d$n),
         n_boot = length(boot))
}

cluster_vcov <- function(X, u, w, cl) {
  bread <- solve(crossprod(X * sqrt(w))); meat <- matrix(0, ncol(X), ncol(X))
  for (ii in split(seq_along(u), cl)) {s <- crossprod(X[ii,,drop=FALSE], w[ii] * u[ii]); meat <- meat + tcrossprod(s)}
  G <- n_distinct(cl); N <- length(u); K <- ncol(X)
  bread %*% meat %*% bread * (G/(G-1)) * ((N-1)/(N-K))
}
rd_one <- function(d, h) {
  d <- d[d$mag < h, ]; if (!nrow(d)) return(NULL)
  x <- ifelse(d$rationed == 1L, -d$mag, d$mag); w <- 1 - abs(x)/h; D <- as.numeric(x < 0)
  X <- cbind(1, D, x, x*D); b <- tryCatch(solve(crossprod(X*sqrt(w)), crossprod(X,w*d$n)), error=function(e) NULL)
  if (is.null(b)) return(NULL)
  u <- as.numeric(d$n-X%*%b); V <- cluster_vcov(X,u,w,d$analysis_date); cells <- d[!duplicated(d$cell_id),]
  c(tau=b[2],se=sqrt(V[2,2]),n_inc=sum(d$n),area_km2=sum(cells$area_m2)/1e6)
}
fit_A <- function(p, hvec = Hb) bind_rows(lapply(bnds, function(b) {
  z <- rd_one(p |> filter(active == 1L, boundary_id == b), hvec[[b]]); if (is.null(z)) return(NULL)
  tibble(boundary_id=b,tau=z[["tau"]],se=z[["se"]],n_inc=z[["n_inc"]],
         area_km2=z[["area_km2"]],bandwidth=hvec[[b]])
}))
pool_A <- function(z) {w <- z$area_km2/sum(z$area_km2); c(tau=sum(w*z$tau),se=sqrt(sum(w^2*z$se^2)),max_weight=max(w))}

Rwat <- panel_result(pan_wat, "08:00--08:00 operational day (primary)")
Rcal <- panel_result(pan_cal, "Calendar day (secondary)")
Awat <- fit_A(pan_wat); Acal <- fit_A(pan_cal); Pwat <- pool_A(Awat); Pcal <- pool_A(Acal)
write_csv(Awat, file.path(OUT, "boundary_estimates_operational.csv"))
write_csv(Acal, file.path(OUT, "boundary_estimates_calendar.csv"))
timing <- bind_rows(Rwat, Rcal) |> mutate(A_tau=c(Pwat[["tau"]],Pcal[["tau"]]), A_se=c(Pwat[["se"]],Pcal[["se"]]))
write_csv(timing, file.path(OUT, "primary_timing.csv"))
message("[05] operational and calendar estimates:"); print(timing)
