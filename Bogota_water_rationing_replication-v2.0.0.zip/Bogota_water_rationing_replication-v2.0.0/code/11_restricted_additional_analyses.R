#!/usr/bin/env Rscript
## =============================================================================
## 11_restricted_additional_analyses.R -- additional analyses that need the native extract.
## Runs only on the restricted path (00_master.R --full). Writes aggregate
## estimates only: no identifier, coordinate or record-level timestamp leaves
## memory.
##
##  R1  Pre-programme placebo. The rationing schedule is applied to dates
##      before 11 April 2024, when no rationing occurred, and Estimator B is
##      re-estimated on the same fixed cells. Two pseudo-calendars:
##        (a) "shifted": the official 306-assignment calendar moved back 364
##            days (same weekday, same alternate-day and holiday structure);
##        (b) "continued": the daily nine-shift rotation run backwards from
##            10 April 2024 to 1 January 2023.
##      July 2023 is excluded because the source extract is incomplete.
##  R2  Other outcomes from the same extract: every MALTRATO circumstance
##      other than MALTRATO A MUJER, and any incident type matching
##      SEXUAL_PATTERN, each with at least MIN_REPORTS geocoded reports.
##  R3  Nearest-active-boundary assignment on the twenty-boundary,
##      operational-clock sample (illustrates the assignment-rule problem).
##  R4  1/k weighting: each report gets weight 1/k across its k fixed-geography
##      boundary placements.
## =============================================================================
suppressPackageStartupMessages({library(sf); library(dplyr); library(readr); library(tidyr)})
ROOT <- Sys.getenv("ROOT", "."); DER <- file.path(ROOT, "data", "derived")
PUB <- file.path(ROOT, "data", "public"); OUT <- file.path(ROOT, "output")
INCIDENTS_ALL <- Sys.getenv("INCIDENTS_ALL", "")
if (!nzchar(INCIDENTS_ALL) || !file.exists(INCIDENTS_ALL)) stop("[11] INCIDENTS_ALL is required for the restricted extensions.")
BIN_W <- 50; MAX_D <- 2000; SEED <- 20240914L; BLOCK_L <- 63L
N_BOOT <- as.integer(Sys.getenv("N_BOOT", "1000"))  # override only for smoke tests
MIN_REPORTS <- as.integer(Sys.getenv("MIN_REPORTS", "2000"))
SEXUAL_PATTERN <- Sys.getenv("SEXUAL_PATTERN", "SEXUAL")
PRE_LO <- as.Date("2023-01-01"); PROG_START <- as.Date("2024-04-11")
INCOMPLETE <- c(as.Date("2023-07-01"), as.Date("2023-07-31"))

## ---- estimators: identical to 05/10 ------------------------------------------
demeanK <- function(v, idx, nlev, tol = 1e-10, maxit = 1000L) {
  v <- as.numeric(v)
  for (iter in seq_len(maxit)) {old <- v
    for (j in seq_along(idx)) v <- v - (rowsum(v, idx[[j]]) / tabulate(idx[[j]], nlev[j]))[idx[[j]]]
    if (max(abs(v - old)) < tol) break}
  v
}
fe_fit <- function(d, y = d$n, x = d$rationed) {
  fs <- list(factor(d$cell_id), factor(d$boundary_date_id)); idx <- lapply(fs, as.integer)
  nl <- vapply(fs, nlevels, integer(1)); yy <- demeanK(y, idx, nl); xx <- demeanK(x, idx, nl)
  den <- sum(xx * xx); if (!is.finite(den) || den <= 0) return(NULL)
  tau <- sum(xx * yy) / den
  list(tau = tau, x = xx, residual = yy - tau * xx, den = den, K = sum(nl) + 1L, n = nrow(d))
}
cluster_se <- function(fit, cl) {
  sc <- vapply(split(seq_along(cl), cl), function(ii) sum(fit$x[ii] * fit$residual[ii]), numeric(1)); G <- length(sc)
  sqrt(sum(sc^2) / fit$den^2 * (G / (G - 1)) * ((fit$n - 1) / (fit$n - fit$K)))
}
moving_block_draws <- function(d, L = BLOCK_L, B = N_BOOT) {
  dates <- sort(unique(d$analysis_date)); nd <- length(dates); by_date <- split(seq_len(nrow(d)), d$analysis_date)
  L <- min(L, nd)
  vapply(seq_len(B), function(rep) {
    starts <- sample.int(nd - L + 1L, ceiling(nd / L), replace = TRUE)
    chosen <- dates[unlist(lapply(starts, function(s) s:(s + L - 1L)))][seq_len(nd)]
    lens <- lengths(by_date[as.character(chosen)])
    s <- d[unlist(by_date[as.character(chosen)], use.names = FALSE), ]
    s$boundary_date_id <- paste(s$boundary_id, rep(seq_along(chosen), lens), sep = "|")
    z <- fe_fit(s); if (is.null(z)) NA_real_ else z$tau
  }, numeric(1))
}
estimate_B <- function(p, label, y = "n") {
  d <- p |> filter(active == 1L, mag < as.numeric(Hb[boundary_id]))
  d$n_use <- d[[y]]
  f <- fe_fit(d, y = d$n_use); set.seed(SEED); bt <- moving_block_draws(transform(d, n = n_use)); bt <- bt[is.finite(bt)]
  b <- mean(d$n_use[d$rationed == 0L])
  tibble(specification = label, tau = f$tau, se_cycle9 = cluster_se(f, d$cycle_id),
         boot_se = sd(bt), ci_lo = unname(quantile(bt, .025)), ci_hi = unname(quantile(bt, .975)),
         control_mean = b, pct = 100 * f$tau / b,
         ci_pct_lo = 100 * unname(quantile(bt, .025)) / b, ci_pct_hi = 100 * unname(quantile(bt, .975)) / b,
         n_rows = nrow(d), n_dates = n_distinct(d$analysis_date), n_placements = sum(d$n_use))
}

## ---- fixed inputs ------------------------------------------------------------
adj <- read_csv(file.path(DER, "adjacency_pairs.csv"), show_col_types = FALSE)
bws <- read_csv(file.path(DER, "bandwidths_mserd.csv"), show_col_types = FALSE)
area <- read_csv(file.path(DER, "cell_exposure_area.csv"), show_col_types = FALSE)
xw <- read_csv(file.path(PUB, "polygon_shift_crosswalk.csv"), show_col_types = FALSE)
p2s <- setNames(xw$shift_id, as.character(xw$polygon_id))
bnds <- sort(unique(adj$boundary_id))
Hb <- setNames(bws$h_mserd[match(bnds, bws$boundary_id)], bnds); Hb[is.na(Hb)] <- median(bws$h_mserd)
cal_off <- read_csv(file.path(PUB, "rationing_calendar.csv"), show_col_types = FALSE) |>
  transmute(date = as.Date(date), shift = as.integer(turno_group_id)) |> arrange(date)
add_cycles <- function(cal) cal |> arrange(date) |> mutate(cycle_id = (row_number() - 1L) %/% 9L + 1L)
poly <- st_read(file.path(DER, "hydraulic_polygons_analysis.gpkg"), quiet = TRUE) |>
  st_zm(drop = TRUE) |> st_make_valid() |> filter(!is.na(polygon_id)) |> arrange(polygon_id)
g <- st_geometry(poly); pid <- poly$polygon_id; gi <- function(k) g[[which(pid == k)]]
lines <- lapply(seq_len(nrow(adj)), function(i) {
  a <- st_sfc(gi(adj$poly_a[i]), crs = 3116); b <- st_sfc(gi(adj$poly_b[i]), crs = 3116)
  st_union(st_intersection(st_boundary(a), st_boundary(b)))
})
sides <- bind_rows(adj |> transmute(boundary_id, side = "a", polygon_id = poly_a),
                   adj |> transmute(boundary_id, side = "b", polygon_id = poly_b))
skel_cell <- sides |> inner_join(area |> select(boundary_id, polygon_id, mag, area_m2), by = c("boundary_id", "polygon_id"))

## ---- read the native extract (same filters as 02, wider dates) ----------------
read_extract <- function(path = INCIDENTS_ALL) {
  ext <- tolower(tools::file_ext(path))
  if (ext == "dsv") {
    z <- read_delim(path, delim = ";", show_col_types = FALSE, progress = FALSE,
                    col_select = c(ID_INCIDENTE, FECHA, HORA, DESC_TIPO_INCIDENTE, CIRCUNSTANCIA_INCIDENTE, LATITUD, LONGITUD)) |>
      transmute(crime_id = as.character(ID_INCIDENTE), date = as.Date(FECHA, "%d-%b-%y"), hour = as.integer(HORA),
                desc = as.character(DESC_TIPO_INCIDENTE), circumstance = as.character(CIRCUNSTANCIA_INCIDENTE),
                lat = as.numeric(LATITUD), lon = as.numeric(LONGITUD)) |>
      filter(!is.na(date), date >= PRE_LO, between(hour, 0L, 23L), is.finite(lat), is.finite(lon), lat != 0, lon != 0) |>
      distinct(crime_id, .keep_all = TRUE)
    pts <- st_as_sf(z, coords = c("lon", "lat"), crs = 4326) |> st_transform(3116)
  } else if (ext == "gpkg") {
    pts <- st_read(path, quiet = TRUE) |>
      transmute(crime_id = as.character(id_inciden), date = as.Date(fecha, "%d-%b-%y"), hour = as.integer(hora),
                desc = as.character(desc_tipo_), circumstance = as.character(circunstan)) |>
      filter(!is.na(date), date >= PRE_LO, between(hour, 0L, 23L)) |> distinct(crime_id, .keep_all = TRUE) |>
      st_transform(3116)
  } else stop("[11] unsupported incident input")
  st_join(pts, poly |> select(polygon_id), left = FALSE, largest = TRUE) |>
    filter(!is.na(polygon_id)) |> distinct(crime_id, .keep_all = TRUE) |>
    mutate(polygon_id = as.integer(polygon_id), water_day = date - as.integer(hour < 8L))
}

## fixed-geography placements: every boundary whose endpoint contains the report, within 2 km
place <- function(inc) bind_rows(lapply(seq_len(nrow(adj)), function(i) {
  sel <- which(inc$polygon_id %in% c(adj$poly_a[i], adj$poly_b[i])); if (!length(sel)) return(NULL)
  dst <- as.numeric(st_distance(inc[sel, ], lines[[i]])); keep <- which(dst < MAX_D); if (!length(keep)) return(NULL)
  tibble(boundary_id = adj$boundary_id[i], crime_id = inc$crime_id[sel][keep], water_day = inc$water_day[sel][keep],
         polygon_id = inc$polygon_id[sel][keep], dist = dst[keep], mag = floor(dst[keep] / BIN_W) * BIN_W + BIN_W / 2)
}))

## operational panel on an arbitrary schedule; usable dates = schedule dates with any citywide record
build_panel <- function(plc, inc, cal, wcol = "w") {
  cal <- add_cycles(cal)
  available <- sort(cal$date[cal$date %in% unique(inc$water_day)])
  sch <- cal |> filter(date %in% available) |> rename(analysis_date = date)
  cnt <- plc |> filter(water_day %in% sch$analysis_date) |>
    group_by(boundary_id, analysis_date = water_day, polygon_id, mag) |> summarise(n = sum(.data[[wcol]]), .groups = "drop")
  skel_cell |> crossing(sch) |>
    mutate(rationed = as.integer(p2s[as.character(polygon_id)] == shift)) |>
    left_join(cnt, by = c("boundary_id", "analysis_date", "polygon_id", "mag")) |>
    left_join(adj |> select(boundary_id, shift_a, shift_b), by = "boundary_id") |>
    mutate(n = coalesce(n, 0), active = as.integer(shift == shift_a | shift == shift_b),
           cell_id = paste(boundary_id, side, mag, sep = "|"),
           boundary_date_id = paste(boundary_id, analysis_date, sep = "|")) |>
    select(-shift_a, -shift_b)
}

INC <- read_extract()
message(sprintf("[11] %s geocoded MALTRATO reports from %s", format(nrow(INC), big.mark = ","), PRE_LO))
dv <- INC |> filter(desc == "MALTRATO", circumstance == "MALTRATO A MUJER")
plc_dv <- place(dv) |> mutate(w = 1)

## ---- consistency: the primary estimate is reproduced from the raw extract ----
pan_main <- build_panel(plc_dv, dv, cal_off)
R0 <- estimate_B(pan_main, "Primary, rebuilt from the native extract")
ref <- read_csv(file.path(OUT, "primary_timing.csv"), show_col_types = FALSE)[1, ]
if (abs(R0$tau - ref$tau) > 1e-10) warning("[11] rebuilt primary estimate differs from primary_timing.csv")

## ---- R1 pre-programme placebos ----------------------------------------------
drop_incomplete <- function(cal) cal |> filter(!(date >= INCOMPLETE[1] & date <= INCOMPLETE[2]))
cal_shift <- cal_off |> mutate(date = date - 364L) |> filter(date >= PRE_LO, date < PROG_START) |> drop_incomplete()
back <- seq(PROG_START - 1L, PRE_LO, by = -1L)
cal_cont <- tibble(date = back, shift = ((cal_off$shift[1] - 2L - (seq_along(back) - 1L)) %% 9L) + 1L) |>
  arrange(date) |> drop_incomplete()
pre_dv <- dv |> filter(water_day < PROG_START)
plc_pre <- plc_dv |> filter(water_day < PROG_START)
R1 <- bind_rows(estimate_B(build_panel(plc_pre, pre_dv, cal_shift), "Pre-programme placebo: official calendar shifted back 364 days"),
                estimate_B(build_panel(plc_pre, pre_dv, cal_cont), "Pre-programme placebo: daily rotation continued backwards"))
write_csv(bind_rows(R0, R1), file.path(OUT, "restricted_preprogramme_placebo.csv"))
message("[11] R1 done")

## ---- R2 other outcomes from the same extract --------------------------------
prog <- INC |> filter(water_day >= PROG_START, water_day <= max(cal_off$date))
cand <- bind_rows(
  prog |> st_drop_geometry() |> filter(desc == "MALTRATO", circumstance != "MALTRATO A MUJER") |>
    count(outcome = paste("MALTRATO:", circumstance), name = "reports"),
  prog |> st_drop_geometry() |> filter(grepl(SEXUAL_PATTERN, desc, ignore.case = TRUE)) |>
    count(outcome = paste("TYPE:", desc), name = "reports"))
write_csv(cand, file.path(OUT, "restricted_outcome_inventory.csv"))
R2 <- bind_rows(lapply(cand$outcome[cand$reports >= MIN_REPORTS], function(o) {
  z <- if (startsWith(o, "MALTRATO: ")) INC |> filter(desc == "MALTRATO", circumstance == sub("^MALTRATO: ", "", o))
       else INC |> filter(desc == sub("^TYPE: ", "", o))
  estimate_B(build_panel(place(z) |> mutate(w = 1), INC, cal_off), o)
}))
write_csv(R2, file.path(OUT, "restricted_other_outcomes.csv"))
message("[11] R2 done")

## ---- R3 nearest-active assignment ----------------------
calc <- add_cycles(cal_off)
act_b <- adj |> select(boundary_id, shift_a, shift_b) |> crossing(calc |> select(date, shift)) |>
  filter(shift == shift_a | shift == shift_b) |> select(boundary_id, water_day = date)
plc_na <- plc_dv |> semi_join(act_b, by = c("boundary_id", "water_day")) |>
  group_by(crime_id) |> slice_min(dist, n = 1, with_ties = FALSE) |> ungroup() |> mutate(w = 1)
pan_na <- build_panel(plc_na, dv, cal_off)
R3 <- estimate_B(pan_na, "Nearest-active assignment (illustration)")
prof <- bind_rows(lapply(seq(125, 1875, by = 250), function(mid) {
  z <- pan_na |> filter(active == 1L, abs(mag - mid) <= 125); f <- fe_fit(z)
  tibble(band_m = mid, estimate = f$tau, se_cycle9 = cluster_se(f, z$cycle_id))
})) |> mutate(t = estimate / se_cycle9)
write_csv(R3, file.path(OUT, "restricted_nearest_active.csv"))
write_csv(prof, file.path(OUT, "restricted_nearest_active_profile.csv"))
message("[11] R3 done")

## ---- R4 1/k weighting --------------------------------------------------------
plc_k <- plc_dv |> group_by(crime_id) |> mutate(w = 1 / n()) |> ungroup()
R4 <- estimate_B(build_panel(plc_k, dv, cal_off, wcol = "w"), "1/k weighting across fixed-geography placements")
kdist <- plc_dv |> count(crime_id, name = "k") |> count(k, name = "reports")
write_csv(R4, file.path(OUT, "restricted_inverse_k.csv"))
write_csv(kdist, file.path(OUT, "restricted_k_distribution.csv"))
message("[11] restricted extensions complete")
