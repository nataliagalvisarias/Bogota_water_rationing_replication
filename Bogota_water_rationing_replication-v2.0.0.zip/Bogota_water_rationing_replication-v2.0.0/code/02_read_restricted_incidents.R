#!/usr/bin/env Rscript
## =============================================================================
## 02_read_restricted_incidents.R -- restricted-input adapter
##
## Reads the Secretariat's native semicolon-delimited extract directly from
## INPUT_ROOT, standardises the fields used by the analysis, and keeps the
## resulting incident-level sf object in memory only.  No coordinates or case
## identifiers are written to the replication package.
## =============================================================================

suppressPackageStartupMessages({
  library(sf); library(dplyr); library(readr)
})

ROOT <- Sys.getenv("ROOT", ".")
INPUT_ROOT <- Sys.getenv("INPUT_ROOT", "")
INCIDENTS_ALL <- Sys.getenv("INCIDENTS_ALL", "")
PUB <- file.path(ROOT, "data", "public")
DER <- file.path(ROOT, "data", "derived")

if (!nzchar(INPUT_ROOT) || !dir.exists(INPUT_ROOT))
  stop("INPUT_ROOT does not exist: ", INPUT_ROOT)
if (!nzchar(INCIDENTS_ALL) || !file.exists(INCIDENTS_ALL))
  stop("INCIDENTS_ALL does not exist: ", INCIDENTS_ALL)

## Figure 2 uses the broader citywide MALTRATO call series, not the female-
## circumstance, geocoded, deduplicated sample used in the boundary analysis.
## This export contains one citywide monthly count per row and no identifiers.
write_monthly_maltrato <- function(path = INCIDENTS_ALL) {
  ext <- tolower(tools::file_ext(path))
  if (ext == "dsv") {
    z <- read_delim(path, delim = ";", show_col_types = FALSE,
                    col_select = c(FECHA, DESC_TIPO_INCIDENTE), progress = FALSE) |>
      transmute(date = as.Date(FECHA, "%d-%b-%y"),
                desc = as.character(DESC_TIPO_INCIDENTE))
  } else if (ext == "gpkg") {
    z <- st_read(path, quiet = TRUE) |>
      st_drop_geometry() |>
      transmute(date = as.Date(fecha, "%d-%b-%y"),
                desc = as.character(desc_tipo_))
  } else {
    stop("Unsupported incident input for monthly series: ", path)
  }
  months <- format(seq(as.Date("2023-01-01"), as.Date("2025-04-01"),
                       by = "month"), "%Y-%m")
  monthly <- z |>
    filter(!is.na(date), date >= as.Date("2023-01-01"),
           date < as.Date("2025-05-01"), desc == "MALTRATO") |>
    mutate(month = format(date, "%Y-%m")) |>
    count(month, name = "maltrato_calls") |>
    right_join(tibble(month = months), by = "month") |>
    mutate(maltrato_calls = tidyr::replace_na(maltrato_calls, 0L)) |>
    arrange(month)
  stopifnot(identical(monthly$month, months))
  write_csv(monthly, file.path(DER, "monthly_maltrato_citywide.csv"))
  message("[02] exported ", nrow(monthly), " citywide monthly MALTRATO counts for Figure 2")
}

read_incidents_all <- function(path = INCIDENTS_ALL) {
  cal <- read_csv(file.path(PUB, "rationing_calendar.csv"), show_col_types = FALSE)
  lo <- min(as.Date(cal$date))
  hi <- max(as.Date(cal$date)) + 1L # carries 00:00--07:59 on the final water-day

  ext <- tolower(tools::file_ext(path))
  if (ext == "dsv") {
    z <- read_delim(
      path, delim = ";", show_col_types = FALSE,
      col_select = c(ID_INCIDENTE, FECHA, HORA, DESC_TIPO_INCIDENTE,
                     CIRCUNSTANCIA_INCIDENTE, LATITUD, LONGITUD),
      progress = FALSE
    ) |>
      transmute(
        crime_id = as.character(ID_INCIDENTE),
        date = as.Date(FECHA, "%d-%b-%y"),
        hour = as.integer(HORA),
        desc = as.character(DESC_TIPO_INCIDENTE),
        circumstance = as.character(CIRCUNSTANCIA_INCIDENTE),
        lat = as.numeric(LATITUD), lon = as.numeric(LONGITUD)
      ) |>
      filter(date >= lo, date <= hi,
             desc == "MALTRATO", circumstance == "MALTRATO A MUJER",
             between(hour, 0L, 23L), is.finite(lat), is.finite(lon),
             lat != 0, lon != 0) |>
      distinct(crime_id, .keep_all = TRUE)
    pts <- st_as_sf(z, coords = c("lon", "lat"), crs = 4326, remove = TRUE) |>
      st_transform(3116)
  } else if (ext == "gpkg") {
    z <- st_read(path, quiet = TRUE) |>
      transmute(
        crime_id = as.character(id_inciden),
        date = as.Date(fecha, "%d-%b-%y"),
        hour = as.integer(hora),
        desc = as.character(desc_tipo_),
        circumstance = as.character(circunstan)
      ) |>
      filter(date >= lo, date <= hi,
             desc == "MALTRATO", circumstance == "MALTRATO A MUJER",
             between(hour, 0L, 23L)) |>
      distinct(crime_id, .keep_all = TRUE)
    pts <- st_transform(z, 3116)
  } else {
    stop("Unsupported incident input. Use the native .dsv or projected .gpkg file.")
  }

  poly <- st_read(file.path(DER, "hydraulic_polygons_analysis.gpkg"), quiet = TRUE) |>
    st_zm(drop = TRUE) |> st_make_valid() |> select(polygon_id)
  joined <- st_join(pts, poly, left = FALSE, largest = TRUE) |>
    filter(!is.na(polygon_id)) |>
    distinct(crime_id, .keep_all = TRUE) |>
    mutate(polygon_id = as.integer(polygon_id))

  message(sprintf("[02] retained %s unique reports in hydraulic polygons (%s--%s)",
                  format(nrow(joined), big.mark = ","), lo, hi))
  joined
}

write_monthly_maltrato()
INC_ALL_SF <- read_incidents_all()
