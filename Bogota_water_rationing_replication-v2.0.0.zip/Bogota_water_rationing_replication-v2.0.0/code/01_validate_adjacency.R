#!/usr/bin/env Rscript
## Shared-edge adjacency on the analysis topology prepared by 00a.
## In the source layer, narrow overlap strips make some polygon boundaries cross
## at points rather than along lines (pairs 6--11, 2--7, 7--8 and 7--11); the
## repaired geometry from 00a yields twenty shared edges. Numeric polygon_id keys
## are used throughout: row positions and Turno metadata never define neighbours.
## Matrices, neighbour lists, and the actual estimation coverage are audited.

suppressPackageStartupMessages({library(sf); library(dplyr); library(readr)})
ROOT <- Sys.getenv("ROOT", "."); DER <- file.path(ROOT,"data","derived")
PUB  <- file.path(ROOT,"data","public"); OUT <- file.path(ROOT,"output")
dir.create(OUT, recursive=TRUE, showWarnings=FALSE)

MIN_SHARED_M  <- 100      # a shared boundary shorter than this is a corner, not an edge
SLIVER_TOL_M2 <- 10       # interior overlap above this is a real overlap, not digitising noise

poly <- st_read(file.path(DER,"hydraulic_polygons_analysis.gpkg"), quiet = TRUE) |>
  st_zm(drop = TRUE) |> st_make_valid() |>
  filter(!is.na(polygon_id)) |> arrange(polygon_id)
stopifnot(st_crs(poly)$epsg == 3116)

xw <- read_csv(file.path(PUB,"polygon_shift_crosswalk.csv"), show_col_types = FALSE)
s  <- setNames(xw$shift_id, as.character(xw$polygon_id))
ids <- poly$polygon_id; g <- st_geometry(poly)

## ---- enumerate every pair whose boundaries meet in a line --------------------
rows <- list()
for (i in seq_along(ids)) for (j in seq_along(ids)) if (i < j) {
  it <- tryCatch(st_intersection(st_boundary(g[i]), st_boundary(g[j])), error = function(e) NULL)
  L  <- if (is.null(it) || !length(it)) 0 else sum(as.numeric(st_length(it)), na.rm = TRUE)
  if (!is.finite(L) || L <= 0) next
  ar <- tryCatch(sum(as.numeric(st_area(st_intersection(g[i], g[j]))), na.rm = TRUE),
                 error = function(e) NA_real_)
  rows[[length(rows) + 1]] <- data.frame(
    poly_a = ids[i], poly_b = ids[j],
    shared_length_m = L, interior_overlap_m2 = ar,
    de9im = st_relate(g[i], g[j])[1, 1],
    strict_F1_rule = st_relate(g[i], g[j], pattern = "F***1****", sparse = FALSE)[1, 1],
    shift_a = s[[as.character(ids[i])]], shift_b = s[[as.character(ids[j])]])
}
cand <- do.call(rbind, rows) |>
  mutate(cross_shift = shift_a != shift_b,
         adjacent = shared_length_m >= MIN_SHARED_M & interior_overlap_m2 <= SLIVER_TOL_M2,
         boundary_id = paste0(pmin(poly_a, poly_b), "_", pmax(poly_a, poly_b))) |>
  arrange(desc(shared_length_m))

write_csv(cand, file.path(OUT, "adjacency_candidates_audit.csv"))

adj <- cand |> filter(adjacent, cross_shift) |>
  select(boundary_id, poly_a, poly_b, shared_length_m, shift_a, shift_b)
write_csv(adj, file.path(DER, "adjacency_pairs.csv"))
stopifnot(nrow(adj)==20L)
W <- matrix(0L,length(ids),length(ids),dimnames=list(as.character(ids),as.character(ids)))
for(k in seq_len(nrow(adj))) {
  W[as.character(adj$poly_a[k]),as.character(adj$poly_b[k])] <- 1L
  W[as.character(adj$poly_b[k]),as.character(adj$poly_a[k])] <- 1L
}
stopifnot(identical(W,t(W)),all(diag(W)==0),all(rowSums(W)>0),
          identical(sort(as.integer(names(which(W["6",]==1L)))),11L),
          identical(sort(as.integer(names(which(W["7",]==1L)))),c(2L,8L,11L)))
write_csv(data.frame(polygon_id=ids,W,check.names=FALSE),file.path(DER,"spatial_weights_binary.csv"))
W_row <- W/rowSums(W)
stopifnot(all(abs(rowSums(W_row)-1)<1e-12),all(diag(W_row)==0))
write_csv(data.frame(polygon_id=ids,W_row,check.names=FALSE),file.path(DER,"spatial_weights_row_standardized.csv"))
write_csv(data.frame(polygon_id=ids,n_neighbors=rowSums(W),
                    neighbors=vapply(seq_along(ids),function(i)
                      paste(ids[W[i,]==1L],collapse=";"),character(1))),
          file.path(DER,"polygon_neighbors.csv"))

## ---- summary of the boundary set ---------------------------------------------
cat("=================== BOUNDARY SET ===================\n")
cat(sprintf("rule: shared boundary >= %d m and interior overlap <= %d m2\n",
            MIN_SHARED_M, SLIVER_TOL_M2))
cat(sprintf("pairs whose boundaries meet in a line : %d\n", nrow(cand)))
cat(sprintf("of which cross-shift and adjacent     : %d\n", nrow(adj)))

## ---- sensitivity of the boundary set to both tolerances ----------------------
cat("\n--- sensitivity of the boundary set to the tolerances ---\n")
grid <- expand.grid(minL = c(0, 100, 500, 1000), tol = c(0, 1, 10, 100))
grid$n_pairs <- mapply(function(mn, tl)
  sum(cand$shared_length_m >= mn & cand$interior_overlap_m2 <= tl & cand$cross_shift),
  grid$minL, grid$tol)
print(as.data.frame(grid), row.names = FALSE)
cat("\nThe repaired topology has 20 edges at the 100 m prespecified minimum.\n")
cat("The shortest edge (7-11) is about 364 m; stricter length screens change the set.\n")
cat("==============================================================\n")
