#!/usr/bin/env Rscript
## Verify file membership, sizes and MD5 digests against docs/FILE_MANIFEST.csv
## and docs/checksums.md5, or regenerate both with --refresh. Run from the
## repository root.
args <- commandArgs(trailingOnly = TRUE)
mode <- if ("--refresh" %in% args) "refresh" else "verify"

## Enumerate the whole package so unexpected root files cannot escape review.
## Git internals and the two self-referential manifest files are excluded.
paths <- list.files(".", recursive = TRUE, all.files = TRUE,
                    full.names = FALSE, include.dirs = FALSE, no.. = TRUE)
paths <- paths[file.exists(paths) & !dir.exists(paths)]
paths <- paths[!grepl("^([.]git(/|$)|docs/(checksums\\.md5|FILE_MANIFEST\\.csv)$)", paths)]
## Locale-dependent collation produced false failures across Linux and macOS.
paths <- sort(unique(paths), method = "radix")

role <- function(p) {
  if (grepl("^code/", p)) return("active-code")
  if (grepl("^data/public/", p)) return("public-source-input")
  if (grepl("^data/derived/(hydraulic_polygons_analysis[.]gpkg|cell_exposure_area[.]csv|adjacency_pairs[.]csv|spatial_weights_.*[.]csv|polygon_neighbors[.]csv)$",p))
    return("derived-public-geography")
  if (p == "data/derived/bandwidths_mserd.csv") return("pinned-analysis-input")
  if (grepl("^data/derived/", p)) return("derived-aggregate")
  if (grepl("^figures/", p)) return("figure")
  if (grepl("^tables/", p)) return("generated-table")
  if (grepl("^output/", p)) return("generated-result")
  if (grepl("^manuscript/", p)) return("manuscript-source")
  "documentation-or-metadata"
}
roles <- unname(vapply(paths, role, character(1)))
disclosure <- ifelse(roles == "derived-aggregate",
                     "aggregate-publication-author-confirmed",
                     ifelse(roles %in% c("public-source-input","derived-public-geography"), "original-publisher-terms",
                            "release-review-required"))
md5 <- unname(tools::md5sum(paths))
manifest <- data.frame(path = paths, bytes = as.integer(file.info(paths)$size),
                       md5 = md5, role = roles, disclosure = disclosure)
md5_lines <- sprintf("%s  %s", md5, paths)
manifest_path <- file.path("docs", "FILE_MANIFEST.csv")
checksum_path <- file.path("docs", "checksums.md5")

if (mode == "refresh") {
  write.csv(manifest, manifest_path, row.names = FALSE, na = "")
  writeLines(md5_lines, checksum_path, useBytes = TRUE)
  message("[09] refreshed ", nrow(manifest), " manifest/checksum entries")
} else {
  if (!file.exists(manifest_path) || !file.exists(checksum_path))
    stop("Manifest or checksum file is missing; run code/09_verify_manifest.R --refresh after review.")
  old <- read.csv(manifest_path, stringsAsFactors = FALSE)
  if (!identical(old, manifest) ||
      !identical(readLines(checksum_path, warn = FALSE), md5_lines)) {
    stop("Manifest/checksum verification failed. Inspect differences before refreshing.")
  }
  message("[09] verified ", nrow(manifest), " files against the manifest")
}
